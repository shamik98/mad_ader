const webpack = require('webpack');
const path = require('path');
const CopyPlugin = require('copy-webpack-plugin');
const srcDir = '../src/';
// const srcDir1 = '../src/web/';

module.exports = {
  entry: {
    helper: path.join(__dirname, srcDir + 'helper.js'),
    login: path.join(__dirname, srcDir + 'login.js'),
    popup: path.join(__dirname, srcDir + 'popup.js'),
    changePass: path.join(__dirname, srcDir + 'changePass.js'),
    background: path.join(__dirname, srcDir + 'background.js'),
    common: path.join(__dirname, srcDir + 'common.js'),
    content: path.join(__dirname, srcDir + 'content.js'),
    forgot: path.join(__dirname, srcDir + 'forgot.js'),
    dashboard: path.join(__dirname, srcDir + 'dashboard.js')
  },
  
  output: {
    path: path.join(__dirname, '../dist/js'),
    filename: '[name].js',
  },
  optimization: {
    splitChunks: {
      name: 'vendor',
      chunks: 'initial',
    },
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        use: 'ts-loader',
        exclude: /node_modules/,
      },
    ],
  },
  resolve: {
    extensions: ['.ts', '.tsx', '.js'],
  },
  plugins: [
    // exclude locale files in moment
    new webpack.IgnorePlugin(/^\.\/locale$/, /moment$/),
    new CopyPlugin([{ from: '.', to: '../' }], { context: 'public' })
  ],
};
