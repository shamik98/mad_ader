var $ = (jQuery = require("jquery"));
var user = require("./helper.js");

$(document).ready(function() {


    $("#eye1").click(function(e) {
        e.preventDefault();
        if (oldPass.type === 'password') {
            oldPass.type = "text";
            $('#eyehide1').hide();
            $('.passwordHide1').show();
        } else {
            oldPass.type = "password";
            $('.passwordHide1').hide();
            $('#eyehide1').show();
        }
    })

    $("#eye2").click(function(e) {
        e.preventDefault();
        if (newpass.type === 'password') {
            newpass.type = "text";
            $('#eyehide2').hide();
            $('.passwordHide2').show();
        } else {
            newpass.type = "password";
            $('.passwordHide2').hide();
            $('#eyehide2').show();
        }
    })

    $("#eye3").click(function(e) {
        e.preventDefault();
        if (confPass.type === 'password') {
            confPass.type = "text";
            $('#eyehide3').hide();
            $('.passwordHide3').show();
        } else {
            confPass.type = "password";
            $('.passwordHide3').hide();
            $('#eyehide3').show();
        }
    })

    $("#chngPwd").click(function() {
        const oldPass = $("#oldPass").val();
        const newPass = $("#newpass").val();
        const confPass = $("#confPass").val();
        if (!validateChangePass(oldPass, newPass, confPass)) return;
        changePass(oldPass, newPass, confPass)


    });

    $(".home").click(function() {
        getCheckCurrentUrl();
    });
});

const validateChangePass = (oldPass, newPass, confPass) => {
    // console.log(oldPass.length);
    if (!oldPass.length || !newPass.length || !confPass.length) {
        showErrorMsg(".errMsg", "All fields are mandatory!", 2000);
        return false;
    } else if (confPass !== newPass) {
        showErrorMsg(
            ".errMsg",
            "New password and Confirm password should match",
            2000
        );
        return false;
    } else if (newPass.length < 6) {
        showErrorMsg(
            ".errMsg",
            "Password should be more than 5 characters",
            2000
        );
        return false;
    } else if (oldPass === newPass) {
        showErrorMsg(
                ".errMsg",
                "Old Password and New password should not match",
                2000
            )
            .finally(() => {

                //   $("#oldPass").val('');
                //   $("#newpass").val('');
                // $("#confPass").val('');
                $("#oldPass").val('');
                $("#newpass").val('');
                $("#confPass").val('');
            });
        return false;
    } else {
        return true;
    }
};
const changePass = (oldPass, newPass, confPass) => {
    // console.log("all pass: ", oldPass, newPass, confPass);
    $.getJSON("kyubiSettings.json", function(configStore) {
        // console.log(configStore);
        chrome.storage.local.get(['user'], function(res) {
            // console.log('user : ', res.user);
            // console.log('token : ', res.user.token);
            fetch(configStore.changePassURL, {
                    method: "POST", // *GET, POST, PUT, DELETE, etc.
                    mode: "cors", // no-cors, cors, *same-origin
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        'Authorization': "KYUBI_" + res.user.token,
                        'Access-Control-Allow-Origin': "*"
                    },
                    body: JSON.stringify({
                        extensionId: configStore.extId,
                        password: oldPass,
                        newPassword: newPass,
                        confirmNewPassword: confPass,
                    }), // body kyubisettings type must match "Content-Type" header
                })
                .then((response) => response.json())
                .then((res) => {
                    // console.log("response:", res);
                    if (res.status) {
                        var confirmation = confirm(res.message)
                        if (confirmation)
                            window.location.href = "./popup.html"
                    } else
                        showErrorMsg(".errMsg", res.message, 2000);
                })
                .catch((err) => {
                    showErrorMsg(
                        ".errMsg",
                        "Failed to change password. Please try again",
                        2000
                    );
                })
                .finally(() => {
                    $("#oldPass").val = '';
                    $("#newpass").val = '';
                    $("#confPass").val = '';
                });
        });
    });
};



const showErrorMsg = (el, msg, autohide = false) => {
    $(el).css("display", "block").text(msg);
    if (autohide) {
        setTimeout(function() {
            $(el).slideUp();
        }, autohide);
    }
};