// import kyubisettings from '../public/kyubiSettings.json'
var $ = (jQuery = require("jquery"));
// console.log("I am in forgot");
const kyubisettings = require("../public/kyubiSettings.json")
const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

$(document).ready(function() {

    $("#forgotPassBtn").click(function() {
        window.location.href = "./login.html";
    })

    $('#forgot').click(async function(e) {
        e.preventDefault();
        // console.log('submit button is clicked');
        let email = $('#forgotPass_email').val();
        // console.log("email: ", email);
        if (email.length == 0) {
            // $('#forgotPass_email').parent().removeClass('error');
            // $('#forgotPass_email').parent().addClass('error');
            $('#error').show();
            $('#error').html("Please provide email id.");
            return;
        }
        if (!emailRegex.test(email)) {
            $('#error').show();
            // $('#forgotPass_email').parent().removeClass('error');
            // $('#forgotPass_email').parent().addClass('error');
            $('#error').html("Please provide valid email id.");
            return;
        }
        // $('#forgotPass_email').parent().removeClass('error');
        let res = await forgotPass(email);
        // console.log("email", email);
        if (res.status) {
            alert(res.message);
            // console.log('response msg:', res.message);
            location.href = 'login.html';
        } else {
            alert(res.message);
            // console.log('response msg:', res.message);
        }
    })
})




async function forgotPass(email) {
    let res = await fetch(kyubisettings.forgotPassURL, {
        method: 'POST',
        mode: 'cors',
        cache: 'no-cache',
        headers: {
            'Content-Type': 'application/json',
        },
        redirect: 'follow',
        referrerPolicy: 'no-referrer',
        body: JSON.stringify({
            extId: kyubisettings.extId,
            email: email
        }),
    });

    let jsonRes = res.json();
    return jsonRes;
}