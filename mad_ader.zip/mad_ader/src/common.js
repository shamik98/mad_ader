var $ = (jQuery = require("jquery"));
// var config = require("./config");
var helper = require("./helper.js");
const configStore = require("../public/kyubiSettings.json");
var port = chrome.runtime.connect({
    name: "Popup-Background",
  });
var regexUrls;


$(document).ready(function() {
    $.getJSON("kyubiSettings.json", async function (result) {
    
        if(result.extId == "60c713bf3436411823224824"){
          console.log("----------------------------",);
          $('.morePower').css('display','block');
        }else{
          $('.morePower').css('display','none');
        }
      });

    helper.checkAuthStatus();
    // $("#logsign").click(function(e){
    //   e.preventDefault();
    //   location.href="login.html"
    // })
    dynamicHTMLContent();

    $("#mad_appName").html(configStore.appName)

    $('a').click(function(e) {
        e.preventDefault();
        let url = $(this).attr('href');
        if (url) {
            window.open(url);
        }
    })

    // $("#clr_acnt").html('Cancel My Account');

    $(".logoutid").click(function() {
        // console.log('logout button is clicked');
        chrome.storage.local.remove(["user"], function() {
        port.postMessage({action : "closeDashoard"});
        window.close();
            // console.log('removed from local storage');
        })
    })

    $('body').on('click', '#openMenu', function() {
        // console.log('logout button is clicked');
        $('#openMenu').hide();
        $('.subMenu').show();
    })
    $('body').on('click', '.cross', function() {
        // console.log('cross button is clicked');
        $('#openMenu').show();
        $('.subMenu').hide();
    })

    $('.cancel').click(function(e) {
        e.preventDefault();
        location.href = 'cancel_account_new.html';
    })

    $('body').on('click', '.change', function() {
        window.location.href = "./changePass.html";
    })


    $("#goBack").click(function(e) {
        e.preventDefault();
        location.href = "popup.html"
    })

});

$("#eye").click(function(e) {
    e.preventDefault();
    if (password.type === 'password') {
        password.type = "text";
        $('#eyehide').hide();
        $('.passwordHide').show();
    } else {
        passwomad_appNamerd.type = "password";
        $('.passwordHide').hide();
        $('#eyehide').show();
    }
})

const dynamicHTMLContent = () => {

    // $.getJSON("kyubiSettings.json", function (result) {
    /* Placing header logo */
    // console.log("configStore.youtubeLink : ", configStore.youtubeLink);
    if (configStore.youtubeLink) {
        $(".youtubeSection").show();
        $("#video").attr("src", configStore.youtubeLink);
    } else {
        $(".youtubeSection").hide();
        $("#video").attr("src", "");
    }
    $("#primarydynamicLogo").html('<img src="' + configStore.logo.primary_logo + '" alt="Logo" style="max-height:102px; max-width:102px"><span id="appTitle"></span>');
    $("#secondarydynamicLogo").html('<img src="' + configStore.logo.secondary_logo + '" alt="Logo" style="max-height:110px; max-width:110px"><span id="appTitle"></span>');
    // $("#appTitle").html(configStore.appName);

    if (configStore.signupURL) {
        $(".afterbtnInfo").show();
        $("#signUp").attr("href", configStore.signupURL);
        $("#signUp").attr("target", "_blank");
    } else {
        $(".afterbtnInfo").hide();
    }

    // $("#mailTo").text(configStore.mailTo);
    if (configStore.changePassURL) {
        $(".change").show();
        $(".change").attr("href", configStore.signupURL);
    } else {
        $(".change").hide();
    }

    if (configStore.mailTo) {
        $(".cancel").show();
        $("#clearAc").attr("href", "mailto:" + configStore.mailTo);
        $("#clearAc").html(configStore.mailTo);
        $("#clearAc").attr("style", " text-decoration: underline; color: white");
    } else {
        $(".cancel").hide();
    }

    if (configStore.footer.showFooter) {
        // console.log("configStore.footer.showFooter true : ", configStore.footer.showFooter);
        if (configStore.footer.poweredBy.willBeDisplayed) {
            if (configStore.footer.poweredBy.url) {
                $("#poweredby").attr("href", configStore.footer.poweredBy.url);
                if (configStore.footer.poweredBy.url == "#")
                    $("#poweredby").removeAttr("target");
            } else {
                $("#poweredby").attr("href", "");
                $("#poweredby").removeAttr("target");
            }
            if (configStore.footer.poweredBy.label)
                $("#poweredby").html(configStore.footer.poweredBy.label);
            else {
                $("#poweredby").hide();
                $("#and").hide();
            }
        } else {
            $("#poweredby").hide();
            $("#and").hide();
        }

        if (configStore.footer.partnership.willBeDisplayed) {
            if (configStore.footer.partnership.url) {
                $("#partnership").attr("href", configStore.footer.partnership.url);
                if (configStore.footer.partnership.url == "#")
                    $("#partnership").removeAttr("target");
            } else {
                $("#partnership").attr("href", "");
                $("#partnership").removeAttr("target");
            }
            if (configStore.footer.partnership.label)
                $("#partnership").html(configStore.footer.partnership.label);
            else {
                $("#partnership").hide();
                $("#and").hide();
            }
        } else {
            $("#partnership").hide();
            $("#and").hide();
        }


        if (configStore.footer.chatSupport.willBeDisplayed) {
            if (configStore.footer.chatSupport.url) {
                $("#chat").attr("href", configStore.footer.chatSupport.url);
            } else {
                $("#chat").hide();
            }
        } else {
            $("#chat").hide();
        }

        if (configStore.footer.officialGroup.willBeDisplayed) {
            if (configStore.footer.officialGroup.url) {
                $("#group").attr("href", configStore.footer.officialGroup.url);
            } else {
                $("#group").hide();
            }
        } else {
            $("#group").hide();
        }
    } else {
        $(".footerTemp").html("");
    }
};