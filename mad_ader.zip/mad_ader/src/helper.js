/** START -- Check Authentication Class */
var $ = (jQuery = require("jquery"));
const configStore = require("../public/kyubiSettings.json");


// const checkAuthStatus = () => {
//   return new Promise((resolve, reject) => {
//     try {
//   chrome.storage.local.get(
//     ["accessToken", "emailID", "deviceID"],
//     function (uData) {
//       if (
//         uData.emailID != null ||
//         uData.emailID != undefined ||
//         uData.emailID != "" && uData.accessToken
//       ) {
//         // console.log("id", uData.deviceID);
//         // // console.log(res.store);
//         // // console.log(res.store.user.email);
//         $.getJSON("kyubiSettings.json", function (configStore) {
//           fetch(configStore.checkUserStatusURL, {
//             method: "POST", // *GET, POST, PUT, DELETE, etc.
//             mode: "cors", // no-cors, cors, *same-origin
//             headers: {
//               "Content-Type": "application/json",
//             },
//             body: JSON.stringify({
//               email: uData.emailID,
//               extId: configStore.extId,
//               deviceId: uData.deviceID,
//             }), // body data type must match "Content-Type" header
//           })
//             .then((response) => response.json())
//             .then((res) => {
//               const resp = res.data ? res.data : res;
//               // console.log("Auth Status", resp);
//               if (resp.status == false) {
//                 resolve(false)
//                 deleteStorage();
//                 redirectUser("login.html");
//               } else{
//                 resolve(true)
//               }
//             })
//             .catch((err) => {
//               resolve(false)
//             });
//         });
//       } else {
//         resolve(false)
//         redirectUser("login.html");
//       }
//     }
//   );
// } catch (e) {
//   resolve(false)
// }
//   })
// };

// this function used to get data from chrome storage
function getParameter(keyArr) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keyArr, function (data) {
          resolve({
              'data': data
          })  
    });
  });
}

function setParameter(keyObj) {
  return new Promise((resolve) => {
      chrome.storage.local.set(keyObj, function (err, data) {
          if (err) {
              resolve({
                  'isError': true
              })
          } else {
              resolve({
                  'isError': false
              })
          }    
      });
  });
}

const checkAuthStatus = () => {
  chrome.storage.local.get(["user"], function (res) {
    if (res && res.user) {
      if (
        res.user.email != null ||
        res.user.email != undefined ||
        res.user.email != ""
      ) {
        fetch(configStore.checkUserStatusURL, {
          method: "POST",
          mode: "cors",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: res.user.email,
            extId: configStore.extId,
            deviceId: res.user.deviceID,
          }),
        })
          .then((response) => response.json())
          .then((res) => {
            const resp = res.data ? res.data : res;

            if (resp.status === false) {
              chrome.storage.sync.remove("user", function () {
                window.location.href = "../login.html";
              });
            }
          })
          .catch((err) => {});
      } else {
        window.location.href = "../login.html";
      }
    }
  });
};

const redirectUser = (page) => {
  window.location.href = page;
};

const deleteStorage = () => {
  chrome.storage.local.clear();
};

const getAdData = () => {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get(["adDatas"], function (res) {
        if (!isEmptyObj(res)) {
          // console.log(res);
          // console.log(res.adDatas.length);
          if(res.adDatas.length > 0)
            resolve(res.adDatas);
          else {
            // console.log("Need to send new array");
             resolve(new Array());
          }
        } else {
          resolve(new Array());
        }
      });
    } catch (e) {
      resolve(new Array());
    }
  });
};


const saveAdData = (arr) => {
  // console.log("arr : ", arr);
  return new Promise(async (resolve, reject) => {
    try {

      let resultStatus = await getParameter(['addCount']);
      let addCount = resultStatus.data.addCount ? Number(resultStatus.data.addCount) + 1 : 1;

      await setParameter({ 'addCount': addCount });

      chrome.storage.local.set({ adDatas: arr }
      , function (res) {
        // console.log("res : ", res);
        resolve(true);
      });
    } catch (e) {
      resolve(false);
    }
  });
};

// this function is called when delete of ads is called from dashboard
const saveAdDataOnDelete = (arr) => {
  // console.log("arr : ", arr);
  return new Promise(async (resolve, reject) => {
    try {

      chrome.storage.local.set({ adDatas: arr }
      , function (res) {
        // console.log("res : ", res);
        resolve(true);
      });
    } catch (e) {
      resolve(false);
    }
  });
};


const isEmptyObj = function (obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
};


module.exports = {
  checkAuthStatus: checkAuthStatus,
  saveAdData: saveAdData,
  getAdData: getAdData,
  saveAdDataOnDelete: saveAdDataOnDelete
};
