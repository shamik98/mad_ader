"use strict";
var $ = (jQuery = require("jquery"));
chrome.storage.local.get(['user'], function(res) {
    // console.log('user : ',res.user);
    // console.log('token : ',res.user.token);
    if (res.user.token !== null && res.user.token !== undefined) {
        //   window.location.href = "./popup.html";
        logout(res.user.email);
    } else {
        window.location.href = "./login.html";
    }
})

$('body').on('click', '#dashboard', function() {
    location.href = "./dashboard.html";
    // var o = $("#dashboard");

    // o.attr("href", "chrome-extension://".concat(chrome.runtime.id, "/dashboard.html"));

})


// function _defineProperty(n, o, t) {
//     return o in n ? Object.defineProperty(n, o, {
//         value: t,
//         enumerable: !0,
//         configurable: !0,
//         writable: !0
//     }) : n[o] = t, n
// }! function a(s, i, c) {
//     // The ! symbol shows that it is an immediately-invoked function expression.
//     function l(o, n) {
//         if (!i[o]) {
//             if (!s[o]) {
//                 var t = "function" == typeof require && require;
//                 if (!n && t) return t(o, !0);
//                 if (p) return p(o, !0);
//                 var e = new Error("Cannot find module '" + o + "'");
//                 throw e.code = "MODULE_NOT_FOUND", e
//             }
//             var r = i[o] = {
//                 exports: {}
//             };
//             s[o][0].call(r.exports, function(n) {
//                 return l(s[o][1][n] || n)
//             }, r, r.exports, a, s, i, c)
//         }
//         return i[o].exports
//     }
//     for (var p = "function" == typeof require && require, n = 0; n < c.length; n++) l(c[n]);
//     return l
// }({
//     1: [function(n, o, t) {
//         var e = n("../utils/constant"),
//             r = e.SHOW_ONLY_ADS_STORAGE,
//             a = e.ADS_STORAGE,
//             s = n("../utils/commun").showBadge;
//         chrome.tabs && chrome.tabs.getSelected(null, function(n) {
//                 // console.log(n);
//                 var o = $("#my-ads-anchor"),
//                     t = $("#facebook-block"),
//                     e = $("#goto_facebook_block");
//                 console.log(n);
//                 if (n.url == undefined) {
//                     $("#facebook-block").hide();
//                     e.show();
//                     o.attr("href", "chrome-extension://".concat(chrome.runtime.id, "/dashboard.html"));
//                 } else {
//                     n.url.indexOf("facebook.com") < 0 ? ($("#facebook-block").hide(), e.show(), o.attr("href", "chrome-extension://".concat(chrome.runtime.id, "/dashboard.html"))) :
//                         (o.attr("href", "chrome-extension://".concat(chrome.runtime.id, "/dashboard.html")), t.show(), e.hide())
//                 }
//             }), chrome.storage.local.get(a, function(n) {
//                 var o = n[a] || [],
//                     t = Object.values(o);
//                     console.log(t);
//                 for (let v = 0; v < t.length; v++) {
//                     if (Object.keys(t[v]).length === 0) {
//                         t.splice(v, 1);
//                     }
//                 }
//                 var e = t.filter(function(n) {
//                     var o = n.favorite,
//                         t = n.hide;
//                     return !!o && !t
//                 }).length;


//                 $("#likes_counter").text(e), $("#found-counter").text(t.length), $("#ads-runner-switcher").prop("disabled", 0 === t.length);
//                 var r = $("#Rate-Us");
//                 0 < t.length ? ($("#no-ads-text").remove(), $("#no-ads-text-2").remove(), r.show()) : r.hide(), s(0 < e ? "".concat(e) : "")
//             }), chrome.storage.local.get(r, function(n) {
//                 $("#ads-runner-switcher").prop("checked", Boolean(n[r]))
//             }), $("#ads-runner-switcher").click(function(n) {
//                 var o = n.target.checked;
//                 chrome.storage.local.set(_defineProperty({}, r, o), function() {})
//             }),
//             $(document).ready(function() {
//                 // $("body").on("click", "a", function() {
//                 //     return chrome.tabs.create({
//                 //         url: $(this).attr("href")
//                 //     }), !1
//                 // })
//             })
//     }, {
//         "../utils/commun": 2,
//         "../utils/constant": 3
//     }],
//     2: [function(n, o, t) {
//         o.exports = {
//             showBadge: function(n) {
//                 return chrome.browserAction.setBadgeText({
//                     text: n
//                 })
//             }
//         }
//     }, {}],
//     3: [function(n, o, t) {
//         var e = new Set(["patrocinado", "sponsored", "sponsorisé", "sponsorizzata", "広告", "赞助内容", "gesponsert", "贊助", "rėmėjai", "5p4m", "ได้รับการสนับสนุน", "may sponsor", "pеклама", "реклама", "ממומן", "مُموَّل", "إعلان مُموَّل", "sponsorizzato", "sponsoreret", "sponzorováno", "gesponsord", "commandité", "प्रायोजित", "bersponsor", "xορηγούμενη", "sponsorowane", "sponzorované", "publicidad", "sponsorlu", "được tài trợ", "reklamo", "patrocinat", "geborg", "la maalgeliyey", "disponsori", "giisponsoran", "sponzorirano", "paeroniet", "spunsurizatu", "noddwyd", "sponsitud", "pəɹosuods", "babestua", "sponsore", "yoɓanaama", "stuðlað", "urraithe", "oñepatrosinapyre", "daukar nauyi", "plaćeni oglas", "icyamamaza ndasukirwaho", "imedhaminiwa", "peye", "sponsorkirî", "apmaksāta reklāma", "remiama", "hirdetés", "misy mpiantoka", "sponsorjat", "sponset", "sponsa", "reklama", "sponsorizat", "patronadu de:", "zvabhadharirwa", "sponsorizuar", "sponsoroitu", "sponsrad", "sponsorıdû", "kostað", "szpōnzorowane", "xορηγούμενη", "pэклама", "cпонсорирано", "سپانسرڈ", "دارای پشتیبانی مالی", "تمويل شوي", "پاڵپشتیکراو", "ܒܘܕܩܐ ܡܡܘܘܢܐ", "পৃষ্ঠপোষকতা কৰা", "স্পনসর করা", "ਸਰਪ੍ਰਸਤੀ ਪ੍ਰਾਪਤ", "પ્રાયોજિત", "ପ୍ରଯୋଜିତ", "விளம்பரம்", "ప్రాయోజితం చేయబడింది", "ಪ್ರಾಯೋಜಿತ", "സ്പോൺസർ ചെയ്തത്", "මුදල් ගෙවා ප්‍රචාරය කරන ලදි", "ຜູ້ສະໜັບສະໜູນ", "အခပေးကြော်ငြာ", "რეკლამა", "የተከፈለበት ማስታወቂያ", "បានឧបត្ថម្ភ", "ⵉⴷⵍ"]);
//         o.exports = {
//             SAVE_MESSAGE: "SAVE",
//             UPDATE_BADGE_MESSAGE: "UPDATE_BADGE_MESSAGE",
//             FB_REFRESH_INTERVAL: 3e5,
//             FB_SCROLL_INTERVAL: 3e4,
//             FB_START_BOT_TIMEOUT: 1e3,
//             SHOW_ONLY_ADS_STORAGE: "hide_organic_posts",
//             ADS_STORAGE: "ads",
//             RATED: "RATED",
//             adWordsSet: e
//         }
//     }, {}]
// }, {}, [1]); // 1,2,3 are arguments

var check = function() {
    return new Promise(resolve => {
        chrome.storage.local.get(['user'], response => {
            // console.log(response);
            if (chrome.runtime.lastError) resolve({
                'user': ''
            });
            resolve((response.user.token === "" || response.user.token == undefined) ? {
                access_token: false,
                username: null
            } : {
                access_token: response.user.token,
                username: response.user.email
            })
        });
    });
};


var logout = function(name) {
    $('body').on('click', '.logoutid', function() {})
}

$(document).ready(function() {

    chrome.storage.local.get('adDatas', (data)=>{
        console.log("adDatas>>>", data['adDatas']);
        $("#addCount").html("Total Ads : " + data['adDatas'].length)
    })

    ////////////////
    // chrome.storage.local.get('addCount', (data)=>{
    //     console.log("adDatas>>>", data.addCount);
    //     let addCount = data['addCount'] ? data['addCount'] : 0;
    //     $("#addCount").html("Total Ads : " + addCount)
    // })
    /////////////////
    
    const addLen = chrome.storage.local.get("addCount") ? chrome.storage.local.get("addCount") : 0;
    $("#addCount").html("Total Ads : " + addLen)
    // console.log(addLen);

    check().then(response => {
        // console.log('Response',response);
        if (response.access_token == false) {
            // console.log('no token is there');
            window.location.href = "./login.html";
        } else {
            logout(response.username);
        }
    }).catch(error =>  console.log(error));
    console.log('here');
    let currentUrl;
    chrome.tabs.query({currentWindow: true, active: true}, function(tabs){
        currentUrl=tabs[0].url;
        console.log('url',currentUrl)
        if(!currentUrl.includes('facebook.com')){
            $("#goto_facebook_block").show()
            $("#facebook-block").hide()
        }
        else{
            $("#goto_facebook_block").hide()
            $("#facebook-block").show()
        }
    });;
    // console.log('url',currentUrl)

})

const createNewDashboardTab=()=>{
    let dataUrl = "../dashboard.html";

    chrome.tabs.query({}, (tabs) => {
      let found = false;
      tabs.forEach((tab) => {
        if (tab.url.includes(dataUrl)) {
          chrome.tabs.update(tab.id, {
            active: true,
          });
          found = true;
        }
      });

      if (!found) {
        chrome.tabs.create({
          url: dataUrl,
        });}
    }
    )
}

$("body").on('click','#dashboard',createNewDashboardTab)
.on('click','#my-ads-anchor',createNewDashboardTab)


