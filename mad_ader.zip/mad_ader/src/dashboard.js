const $ = (jQuery = require("jquery"));
const configStore = require("../public/kyubiSettings.json");
const helper = require("./helper.js");
// const { google } = require('googleapis');
var linkShow,imgShow;

var port = chrome.runtime.connect({
    name: "Popup-Background",
  });

$(document).ready(async function() {
    // console.log("doc is ready.");

    $("#refresh-ads").click(function() {
        // console.log("hghmxhxmhfxx");
        window.location.reload();
    });


    const ads_data = await helper.getAdData();
    // console.log("ads_data.length : ", ads_data);
    // console.log("ads_data.length : ", !ads_data.length);
    if(!ads_data.length){
        $('.tableInfo').html('<div class="no_result">No ads data is there.</div>');
    }
    $("#listCount").html(ads_data.length)
    const gsheetDatas = await getGSheetDatas(ads_data);
    // console.log("gsheetDatas: ", gsheetDatas);
    

    if (ads_data.length) {
        ads_data.forEach((el, i) => {
    // console.log("ads_data.length : ", el.reasonsOfAds);

            // console.log(i + " : ", el); // id="openMenu"
            // console.log("reactCount : " + i + " : ", el.reactCount); // id="openMenu"
            // console.log("reactEmot : " + i + " : ", el.reactEmot); // id="openMenu"

            // console.log("companyLogo: ", el.companyLogo);
            if (el.adImage) {
                imgShow = `<img class="imgImg" src="${el.adImage}" />`;;
            }else
                imgShow = `<img class="imgImg" src="../images/noimageavailable.png" />`;

            const description = el.postCopy ? el.postCopy : "N/A"
            const headline = el.headline ? el.headline : "N/A"
            const reasonsOfAds = el.reasonsOfAds ? el.reasonsOfAds :  "N/A" ;
            // console.log('reasons::'+i+' ',reasonsOfAds);
            let headlineInfo, despcriptionInfo, reasonsOfAdsInfo;
            if (headline.length > 100) {
                headlineInfo = `<p class="headLineHide" style="display: none;">${headline}</p><p class="headLineShow">${headline.substring(0,100)}</p><a class="btnMore finalHL" id="finalHL">See More</a>`
            } else {
                headlineInfo = `<p>${headline.substring(0,100)}</p>`
            }
            if (description.length > 100) {
                despcriptionInfo = `<p class="descHide" style="display: none;">${description}</p><p class="descShow">${description.substring(0,100)}</p><a class="btnMore morelink" id="morelink">See More</a>`
            } else {
                despcriptionInfo = `<p>${description.substring(0,100)}</p>`
            }
            if (reasonsOfAds.length > 100) {
                reasonsOfAdsInfo = `<p class="reasonsHide" style="display: none;">${reasonsOfAds}</p><p class="reasonsShow">${reasonsOfAds.substring(0,100)}</p><a class="btnMore whyLink" id="whyLink">See More</a>`
            } else {
                reasonsOfAdsInfo = `<p>${reasonsOfAds.substring(0,100)}</p>`
            }
            // console.log("reasonsOfAds "+i+ " :: ", reasonsOfAds);
            // console.log("reasonsOfAdsInfo "+i+ " :: ", reasonsOfAdsInfo);
            if (el.postUrl) {
                linkShow = `<a href="${el.postUrl}" class="btn btn-primary" target="_blank"><img src="images/links.png" class="linksImages"></a>`;
            } else {
                linkShow = `<a href="#" class="btn btn-primary" ><img src="images/links.png" class="linksImages"></a>`;
            }
            const oldestCommentAge = el.oldestCommentAge?el.oldestCommentAge:'N/A'
            // console.log("el.companyPageName : ", el.companyPageName);
            var ads_Block = `<ul class="individualRow onlyData" id=ul${i} key=${el.key}>
            <li class="checkBoxs">
            <label class="checkboxLabel" index=${i}> <img src="${el.companyLogo}" class="checkboxImages">
            <a href='#' class='compName' index=${i}>${el.companyPageName}</a>
            <input type="checkbox" id="inputChk-${i}" class="allcheckbox" value="">
            <span class="checkmark newClass" id="inputChkSpan-${el.companyPageName}">
            </span>
            </label>
            </li>
            <li class="images">
            ${imgShow}
            </li>` +
                `<li class="headlineInfo">${headlineInfo}</li>
            <li class="despcriptionInfo">${despcriptionInfo}</li>
            <li class="despcriptionInfo seeAdd">${reasonsOfAdsInfo}</li>
            <li class="linkImgs">
            ${linkShow}
            </li>
			<li class="commentsInfo">${el.comments?el.comments:0}</li>
            <li class="sharesInfo">${el.shares?el.shares:0}</li> 
            <li class="reactionsInfo" id="reactionsInfo${i}">`
            +
            // +
            // <span class="reactionSpan"><span class="reactNames"><img src="./images/like.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.like?el.like:0}</span></span>
            // <span class="reactionSpan"><span class="reactNames"><img src="../images/love.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.love?el.love:0}</span></span>
            // <span class="reactionSpan"><span class="reactNames"><img src="../images/care.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.care?el.care:0}</span></span>
            // <span class="reactionSpan"><span class="reactNames"><img src="../images/laugh.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.haha?el.haha:0}</span></span>
            // <span class="reactionSpan"><span class="reactNames"><img src="../images/wow.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.wow?el.wow:0}</span></span>
            // <span class="reactionSpan"><span class="reactNames"><img src="../images/sad.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.sad?el.sad:0}</span></span>
            // <span class="reactionSpan"><span class="reactNames"><img src="../images/angry.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.angry?el.angry:0}</span></span>
            // +
            `</li>
            <li class="reaction oldComment"><p>${oldestCommentAge}</p></li>
          </ul>`;
            $('.listTables').append(ads_Block);
            $("#listCount").text(ads_data.length);
        })
        ads_data.forEach((el, i) => {
            // console.log("el : ", el);
            // console.log("reactEmot"+i+" ::: ", el.reactEmot);
            // console.log("reactCount"+i+" ::: ", el.reactCount);
            if(el.reactCount){
                el.reactEmot.forEach((reactEmot,j)=>{
                    $(`#reactionsInfo${i}`).append(`<span class="reactionSpan"><span class="reactNames"><img src=${reactEmot} alt="" width="12px"></span> : <span class="reactinfo" id="reactinfo${j}">0</span></span>`)
                })
                el.reactCount.forEach((reactCount,j)=>{
                    $($(`#reactionsInfo${i}`).find("#reactinfo"+j)).text(reactCount);
                })
            }else{
                $(`#reactionsInfo${i}`).append(`<span class="reactionSpan">N/A</span>`)
            }
        })
    }


    

    $("form.search").submit(async function(e) {
        e.preventDefault();
        $(".onlyData").empty();

        var temp_str_length = 0;
        // console.log("val() : ", $("#search").val());
        var isThere= false;
        $('.listTables').html("");
        if(ads_data.length){
            ads_data.forEach((el, i) => {
                if (
                    el.companyPageName
                    .toLowerCase()
                    .includes($("#search").val().toLowerCase()) ||
                    el.postCopy
                    .toLowerCase()
                    .includes($("#search").val().toLowerCase()) ||
                    el.headline
                    .toLowerCase()
                    .includes($("#search").val().toLowerCase())
                ) {
                    temp_str_length++;
                    if (el.adImage) {
                        imgShow = `<img class="imgImg" src="${el.adImage}" />`;;
                    }else
                        imgShow = `<img class="imgImg" src="../images/noimageavailable.png" />`;
        
                    const description = el.postCopy ? el.postCopy : ""
                    const headline = el.headline ? el.headline : ""
                    const reasonsOfAds = el.reasonsOfAds ? el.reasonsOfAds :  "" ;
                    // console.log('reasons::'+i+' ',reasonsOfAds);
                    let headlineInfo, despcriptionInfo, reasonsOfAdsInfo;
                    if (headline.length > 100) {
                        headlineInfo = `<p class="headLineHide" style="display: none;">${headline}</p><p class="headLineShow">${headline.substring(0,100)}</p><a class="btnMore finalHL" id="finalHL">See More</a>`
                    } else {
                        headlineInfo = `<p>${headline.substring(0,100)}</p>`
                    }
                    if (description.length > 100) {
                        despcriptionInfo = `<p class="descHide" style="display: none;">${description}</p><p class="descShow">${description.substring(0,100)}</p><a class="btnMore morelink" id="morelink">See More</a>`
                    } else {
                        despcriptionInfo = `<p>${description.substring(0,100)}</p>`
                    }
                    if (reasonsOfAds.length > 100) {
                        reasonsOfAdsInfo = `<p class="reasonsHide" style="display: none;">${reasonsOfAds}</p><p class="reasonsShow">${reasonsOfAds.substring(0,100)}</p><a class="btnMore whyLink" id="whyLink">See More</a>`
                    } else {
                        reasonsOfAdsInfo = `<p>${reasonsOfAds.substring(0,100)}</p>`
                    }
                    if (el.postUrl) {
                        linkShow = `<a href="${el.postUrl}" class="btn btn-primary" target="_blank"><img src="images/links.png" class="linksImages"></a>`;
                    } else {
                        linkShow = `<a href="#" class="btn btn-primary" ><img src="images/links.png" class="linksImages"></a>`;
                    }
                    const oldestCommentAge = el.oldestCommentAge?el.oldestCommentAge:'N/A'
                    // console.log("el.companyPageName : ", el.companyPageName);
                    var ads_Block = `<ul class="individualRow onlyData" id=ul${i} key=${el.key}>
                    <li class="checkBoxs">
                    <label class="checkboxLabel" index=${i}> <img src="${el.companyLogo}" class="checkboxImages">
                    <a href='#' class='compName' index=${i}>${el.companyPageName}</a>
                    <input type="checkbox" id="inputChk-${i}" class="allcheckbox" value="">
                    <span class="checkmark newClass" id="inputChkSpan-${el.companyPageName}">
                    </span>
                    </label>
                    </li>
                    <li class="images">
                    ${imgShow}
                    </li>` +
                        `<li class="headlineInfo">${headlineInfo}</li>
                    <li class="despcriptionInfo">${despcriptionInfo}</li>
                    <li class="despcriptionInfo seeAdd">${reasonsOfAdsInfo}</li>
                    <li class="linkImgs">
                    ${linkShow}
                    </li>
                            <li class="commentsInfo">${el.comments?el.comments:0}</li>
                    <li class="sharesInfo">${el.shares?el.shares:0}</li> 
                    <li class="reactionsInfo" id="reactionsInfo${i}">`+
                    // <span class="reactionSpan">
                    // <span class="reactNames"><img src="./images/like.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.like?el.like:0}</span></span>
                    // <span class="reactionSpan"><span class="reactNames"><img src="../images/love.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.love?el.love:0}</span></span>
                    // <span class="reactionSpan"><span class="reactNames"><img src="../images/care.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.care?el.care:0}</span></span>
                    // <span class="reactionSpan"><span class="reactNames"><img src="../images/laugh.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.haha?el.haha:0}</span></span>
                    // <span class="reactionSpan"><span class="reactNames"><img src="../images/wow.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.wow?el.wow:0}</span></span>
                    // <span class="reactionSpan"><span class="reactNames"><img src="../images/sad.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.sad?el.sad:0}</span></span>
                    // <span class="reactionSpan"><span class="reactNames"><img src="../images/angry.gif" alt="" width="12px"></span> : <span class="reactinfo">${el.angry?el.angry:0}</span></span>
                    `</li>
                    <li class="reaction oldComment"><p>${oldestCommentAge}</p></li>
                </ul>`;
                isThere = true;                
                    $('.listTables').append(ads_Block);
                }
            })

            ads_data.forEach((el, i) => {
                console.log("el : ", el);
                console.log("reactEmot"+i+" ::: ", el.reactEmot);
                console.log("reactCount"+i+" ::: ", el.reactCount);
                if(el.reactEmot){
                    el.reactEmot.forEach((reactEmot,j)=>{
                        $(`#reactionsInfo${i}`).append(`<span class="reactionSpan"><span class="reactNames"><img src=${reactEmot} alt="" width="12px"></span> : <span class="reactinfo" id="reactinfo${j}">0</span></span>`)
                    })
                    el.reactCount.forEach((reactCount,j)=>{
                        $($(`#reactionsInfo${i}`).find("#reactinfo"+j)).text(reactCount);
                    })
                }
            })
        }
        // console.log("is there : ", isThere);
        if(!isThere)
            $('.listTables').html('<div class="no_result">No Result found</div>');
        $("#listCount").text(temp_str_length);
    });


    $("#inputChk-d").click(function(){
        // console.log("hgcghf");
      if ($($("#inputChk-d")).is(":checked")){
        // console.log("checked");
        $(".allcheckbox").prop("checked",true)
      }else{
        //  // console.log("Not checked");
        $(".allcheckbox").prop("checked",false)

      }
    })

    $(".compName").click(function (e) {
        // console.log("jefkjlskjlkh");
        var elCfFunnel = $(this);
        // console.log("elCfFunnel::: ",elCfFunnel)
        var indx = elCfFunnel.attr("index");
        // console.log("y::: ",indx)
        //   // console.log(ads_data[indx]);
          openAdLibraryUrl(ads_data[indx]);
      });

    $(".okDelete").click(function() {
        // $("#willDelete").hide();
        var key_arr = [];
        if (ads_data.length) {
            ads_data.forEach((el, i) => {
                // console.log(i + " : ", $(`#inputChk-${i}`)[0]);
                if (!$($(`#inputChk-${i}`)[0]).is(":checked")) {
                    key_arr.push(el)
                }
            })
            // console.log("key_arr : ", key_arr);
            // helper.saveAdData(key_arr);
            helper.saveAdDataOnDelete(key_arr);
            window.location.reload();
        }
    })

    $('body').on('click', '.finalHL', function() {
        const headlineBlock = $(this)[0].closest(".headlineInfo")
        $($(headlineBlock).find(".headLineHide")).show();
        $($(headlineBlock).find(".headLineShow")).hide();
        $(this).hide();
    })

    $('body').on('click', '.morelink', function() {
        const descriptionBlock = $(this)[0].closest(".despcriptionInfo")
        // $(descriptionBlock).html(`<p>${finalDesc}</p>`)
        $($(descriptionBlock).find(".descHide")).show();
        $($(descriptionBlock).find(".descShow")).hide();
        $(this).hide();
    })

    $('body').on('click', '.whyLink', function() {
        const descriptionBlock = $(this)[0].closest(".seeAdd")
        // $(descriptionBlock).html(`<p>${finalDesc}</p>`)
        $($(descriptionBlock).find(".reasonsHide")).show();
        $($(descriptionBlock).find(".reasonsShow")).hide();
        $(this).hide();
    })


    $(".downloadBtn").click(function() {
        var result = $('input[value=" CSV"]:checked');
        if (result.length > 0) {
            
            exportToCsv(ads_data);
        } else {
            // console.log("Not checked");
        }
        var resultSheet = $('input[value=" Google Sheet"]:checked');
        // if ($("#checkgs").prop("checked",true)) {
        if (resultSheet.length > 0) {
            // console.log("checked");
            $(".SpreadSheet").show();
            $("#downloadModal").hide();
        } else {
            // console.log("Not checked");
        }
    })

    $("#sheetsubmit").click(function() {
        // console.log("Goole sheet");
        var spreadSheetURL = $('input[name="spreadsheetUrl"]').val();
        // console.log("spreadSheetURL : ", spreadSheetURL);
        if (spreadSheetURL.length == 0) {
            // console.log("Provide Spreadsheet URL.");
            showErrorMsg("#errmsg", "Provide Spreadsheet URL.", 3000);
            return;
        }
        if (spreadSheetURL.split("/")[5] == undefined) {
            // console.log("Invalid URL");
            showErrorMsg("#errmsg", "Invalid url", 3000);
            $('input[name="spreadsheetUrl"]').val('');
            // console.log("thatvalu",spreadSheetURL);
            return;
        }
        downLoadInSpreadsheet(spreadSheetURL.split("/")[5], gsheetDatas)
    });

    $(".headerhBtnDeletes").click(function() {
        $("#downloadModal").show();
        ($("#checkcsv").prop("checked",false))
        ($("#checkgs").prop("checked",false))
    })

    $(".deleteBtn").click(function() {
        var isChecked = false;
        if (ads_data.length) {
            ads_data.forEach((el, i) => {
                // console.log(i + " : ", $(`#inputChk-${i}`)[0]);
                if ($($(`#inputChk-${i}`)[0]).is(":checked")) {
                    isChecked = true;
                }
            })
            // console.log("isChecked : ", isChecked);
            if (isChecked) {
                $("#willDelete").show();
            } else {
                $("#notcheckDelete").show();
            }
        }
    })

    $(".deletecancel").click(function() {
        // console.log($(this).closest(".downloadModal"));
        $(this).closest(".downloadModal").hide();
    })


    $("body").on("click", "#openMenu", function() {
        $(".subMenu").show();
    });
    $("body").on("click", ".cross", function() {
        $(".subMenu").hide();
    });

    $("#downloadcancel").click(function() {
        $(".downloadModal").hide();
        $(".SpreadSheet").hide();
    })

    $("#spreadsheetcancel").click(function() {
        $("#checkgs").prop("checked",false)
        // $("#checkcsv").prop("checked",false)
        // console.log("not checked");
        $(".SpreadSheet").hide();
        $(".downloadModal").hide();
    })

    if (configStore.footer.chatSupport.willBeDisplayed) {
        if (configStore.footer.chatSupport.label) {
            $("#chatLabel").html(configStore.footer.chatSupport.label);
        } else {
            $("#chatLabel").hide();
        }
    } else {
        $("#chatLabel").hide();
    }

    if (configStore.footer.officialGroup.willBeDisplayed) {
        if (configStore.footer.officialGroup.label) {
            $("#groupLabel").html(configStore.footer.officialGroup.label);
        } else {
            $("#groupLabel").hide();
        }
    } else {
        $("#groupLabel").hide();
    }

})
/////////////////////////////////////////////////////////////
const downLoadInSpreadsheet = async (id, gsheetDatas) => {
    console.log("id", id);
    console.log("gsheetdata", gsheetDatas);


    fetch(`https://api.groupmonkey.io/api/helper/send-to-sheet/acf42fa1-dfd2-44bf-87db-c17ba5d92808`, {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            mode: "cors", // no-cors, cors, *same-origin
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({
                spreadsheetId: id,
                data: gsheetDatas
            }), // body data type must match "Content-Type" headerbody data type must match "Content-Type" header
        })
        .then((response) => response.json())
        .then((res) => {
            
            if (res.success == false) {
                showErrorMsg("#errmsg", "Please make sure the Spread sheet link is Publicly Editable.", 3000);
                $('input[name="spreadsheetUrl"]').val('');
            } else if (res.success == true) {
                showErrorMsg("#succmsg", "Data has succesfully sent to the sheet.", 3000);
                $('input[name="spreadsheetUrl"]').val('');
            }
        })
        .catch((err) => {
            // console.log("err after google sheet api hit :: ", err);
            return;
        })
}
//////////////////////////////////////////////////

const showErrorMsg = (el, msg, autohide = false) => {
    $(el).css("display", "block").text(msg);
    if (autohide) {
        setTimeout(function() {
            $(el).slideUp();
        }, autohide);
    }
};

const getGSheetDatas = (ads_data) => {
    return new Promise((resolve, reject) => {
        try {
            if (ads_data.length) {
                // console.log("In if ads_data.length: ", ads_data.length);
                let gsDatas = [];
                let Datas = [["Company Name","Image Url","Why I'm seeing this AD", "Headline", "Description", "Url","comments","shares" , "like", "love", "care", "haha", "wow", "sad", "angry" ]];     
                // let Datas = [];
                ads_data.forEach((el, i) => {
                    let reasonsOfAds = el.reasonsOfAds ? el.reasonsOfAds :  "N/A" ;
                    if (reasonsOfAds.length > 100) {
                        reasonsOfAds = reasonsOfAds.substring(0,100)
                    }
                    Datas.push([
                        el.companyPageName,
                        el.companyLogo,
                        reasonsOfAds,
                        el.headline,
                        el.postCopy,
                        el.postUrl,
                        el.comments,
                        el.shares,
                        el.like,
                        el.love,
                        el.care,
                        el.haha,
                        el.wow,
                        el.sad,
                        el.angry,
                    ]);
                })
                resolve(Datas);
            }
            //   });
        } catch (e) {
            resolve(new Array());
        }
    });
}

function exportToCsv(ads_data) {
    console.log("ads_data============",ads_data);
    var Results = [
        ["Company Name", "Image Url","Why I'm seeing this AD", "Headline", "Description", "Url", "comments", "shares", "oldestCommentAge", "like", "love", "care", "haha", "wow", "sad", "angry"]
    ];
    ads_data.forEach((el, i) => {
        let reasonsOfAds = el.reasonsOfAds ? el.reasonsOfAds :  "N/A" ;
        // if (reasonsOfAds.length > 100) {
        //     reasonsOfAds = reasonsOfAds.substring(0,100)
        // }
        Results.push([
            el.companyPageName,
            el.companyLogo,
            reasonsOfAds,
            el.headline,
            el.postCopy,
            el.postUrl,
            el.comments,
            el.shares,
            el.oldestCommentAge,
            el.like,
            el.love,
            el.care,
            el.haha,
            el.wow,
            el.sad,
            el.angry,

        ]);
        // console.log("Results", Results);
    })
    var CsvString = "";
    Results.forEach(function(RowItem, RowIndex) {
        RowItem.forEach(function(ColItem, ColIndex) {
            var colVal = ColItem;

            if (ColItem && ColItem.includes(",")) {
                colVal = ColItem.replace(/,/g, ".");
            }
            CsvString += colVal + ",";
        });
        CsvString += "\r\n";
    });

    CsvString = "data:application/csv," + encodeURIComponent(CsvString);
    var x = document.createElement("A");
    x.setAttribute("href", CsvString);
    x.setAttribute("download", "Fb_Ads.csv");
    document.body.appendChild(x);
    x.click();
}


// chrome.storage.local.get(["selected", "data"], (result) => {
//     if (
//         result.access_token !== "" &&
//         result.access_token !== false &&
//         (result.uid !== "" || result.uid !== undefined)
//     ) {
//         // data_fetch(result);
//         // // console.log('working');
//     }
// });

// chrome.storage.local.get(["user"], function(res) {
//     // // console.log("user : ", res.user);
//     // // console.log("token : ", res.user.token);
//     if (res.user.token !== null && res.user.token !== undefined) {} else {
//         // window.location.href = "./login.html";
//     }
// });

chrome.storage.local.get("user", function(res) {
    $("#userName").text(res.user.email);
});

function openAdLibraryUrl(payloads, index) {
    const payload = {
      action: "openAdLibrary",
      url: payloads.companyUrl,
    };
    // console.log(" payload : ", payload);
    port.postMessage(payload);
}