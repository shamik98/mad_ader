// const configStore = require("../public/kyubiSettings.json");
// const helper = require("./helper.js");

  // document.addEventListener("DOMContentLoaded", function () {
  //   // console.log("DOM CONTENT LOADED")
  //   if ('serviceWorker' in navigator) {
  //   //  // console.log("requesting permission")
  //   Notification.requestPermission(function (result) {
  //     // console.log("result : ", result)
  //     if (result === 'granted') {
  //     sendFn().catch(e => console.error('EERR : ', e))
  //     }
  //   })
  //   }
  // });

  // function urlBase64ToUint8Array(base64String) {
  //   const padding = '='.repeat((4 - base64String.length % 4) % 4);
  //   const base64 = (base64String + padding)
  //   .replace(/-/g, '+')
  //   .replace(/_/g, '/');

  //   const rawData = window.atob(base64);
  //   const outputArray = new Uint8Array(rawData.length);

  //   for (let i = 0; i < rawData.length; ++i) {
  //   outputArray[i] = rawData.charCodeAt(i);
  //   }
  //   return outputArray;
  // }

  // // Register the service worker
  // // Register Push
  // // Send the push
  // const sendFn = async () => {
  //   // Register SErvice Worker
  //   // console.log("Registering service worker")
  //   const register = await navigator.serviceWorker.register('./worker.js', {
  //   scope: '/'
  //   })

  //   // console.log('waiting for ready : ', register)
  //   await navigator.serviceWorker.ready;

  //   // console.log('register service worker : ', register)

  //   const subscription = await register.pushManager.subscribe({
  //   userVisibleOnly: true,
  //   applicationServerKey: urlBase64ToUint8Array(configStore.publicVapidKey)
  //   })
  //   // console.log('Push registered..', subscription)

  //   chrome.storage.sync.set({
  //   subscription: JSON.parse(JSON.stringify(subscription))
  //   }, function () {
  //   // chrome.storage.sync.get(['subscription'], function(sub) {
  //     //  // console.log('sub : ', subscription)

  //   //   // ycePorts.loginResponsePort.postMessage({"subscription": sub.subscription})
  //   // })
  //   })
  // }

  // chrome.storage.local.get(["adDatas"], function (result) {
  //   if(isEmptyObj(result)){}
  // });

  chrome.storage.local.get(["adDatas"], function (result) {
    // console.log(result);
    // console.log(result.adDatas);
    // if(!result || !result.adDatas)
      if(result.adDatas==undefined)
        chrome.storage.local.set({ adDatas: [] });
  });


chrome.storage.onChanged.addListener(async function(changes, namespace) {
  // console.log("changes : ", changes.adDatas);
      //  // console.log("changes != null  && changes.adDatas != null && changes.adDatas.newValue[variableName] != changes.adDatas.oldValue[variableName]",
      //  changes != null
      //  && changes.adDatas != null
      //  && changes.adDatas.newValue != null
      //  && changes.adDatas.oldValue != null)
          if(changes != null
          && changes.adDatas != null
          && changes.adDatas.newValue != null
          && changes.adDatas.oldValue != null)
          {
                const newLength = (changes.adDatas.newValue).length;
                const oldLength = (changes.adDatas.oldValue).length;
                // console.log("oldLength : ",oldLength);
                // console.log("newLength : ",newLength);
                if(newLength>0 && newLength>oldLength){
                  // console.log("greater than 0");
                  const totalAds =  await getAdData();
                  // console.log(totalAds);
                  const totalAdsLength = totalAds.length;
                  // console.log(totalAdsLength);
                  const addCount = chrome.storage.local.get("addCount");
                    if(addCount){
                      if(totalAdsLength){
                        if(addCount<totalAdsLength)
                          chrome.storage.local.set("addCount" , parseInt(totalAdsLength)) 
                        else
                          chrome.storage.local.set("addCount" , parseInt(addCount)+parseInt(newLength-oldLength))
                      }
                    } else {
                      totalAdsLength ? chrome.storage.local.set("addCount" , parseInt(totalAdsLength)) : chrome.storage.local.setItem("addCount" , 0)
                    }
                }
                else{
                  var addCountLen = chrome.storage.local.get("addCount");
                  if(!addCountLen)  chrome.storage.local.set("addCount" , 0);
                  // addCount ? localStorage.setItem("addCount" , parseInt(addCount)) : localStorage.setItem("addCount" , 0); 
                }
          }
          // if(changes != null
          //   && changes.user != null
          //   && changes.user.newValue != null
          //   && changes.user.oldValue != null)
          //   {
              // console.log("changes : ", changes.user);
            // }
})      


const getAdData = () => {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get(["adDatas"], function (res) {
        if (!isEmptyObj(res)) {
          resolve(res.adDatas);
        } else {
          resolve(new Array());
        }
      });
    } catch (e) {
      resolve(new Array());
    }
  });
};


const isEmptyObj = function (obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
};



chrome.runtime.onConnect.addListener(function (port) {
  // // console.log("Connected .....");
  port.onMessage.addListener(function (msg) {
    // console.log("msg : ", msg);
    switch (msg.action) {
      case "openAdLibrary":
        // console.log(msg);
        openSendMessage(msg);
        break;
      case "closeDashoard" :
        closeDashoard();
      default:
        //// console.log("Default case");
        break;
    }
  });
});

/**
 * OPEN A TAB & SEND MESSAGE TO CONTENT SCRIPT USING CHROME API
 * @param {Object} payload Payload to send with message
 */
 function openSendMessage(msg) {
  // // console.log("payload :: ", payload);
  openUrl(msg.url)
    .then(tab => checkTabStatus(tab))
    .then(tab => {
      // console.warn("Send Message Tab", tab);
      // console.warn("Payload", payload);
      setTimeout(() => {
        chrome.tabs.sendMessage(tab.id, msg, function (res) {
          // // console.log(res);
        });
      }, 1000);
    })
    .catch(e => {
      // // console.log("ERROR", e);
    });
}

/**
 * CREATING A NEW TAB WITH THE URL
 * @param {String} url The url to which will open
 */
const openUrl = url => {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.create({ url: url }, function (tab) {
        resolve(tab);
      });
    } catch (e) {
      reject(e.message);
    }
  });
};

/**
 * CHECKING THE STATUS OF THE FOCUSED TAB WHETHER LOADED OR STILL LOADING
 * @param {Object} tab Gives the state of the tab
 */
const checkTabStatus = tab => {
  return new Promise((resolve, reject) => {
    try {
      chrome.tabs.onUpdated.addListener(function delPendinglistener(tabId, info) {
        if (info.status === "complete" && tabId === tab.id) {
          // // console.log("Tab Info", info);
          chrome.tabs.onUpdated.removeListener(delPendinglistener);
          tab.status = info.status;
          resolve(tab);
        }
      });
    } catch (e) {
      reject(e.message);
    }
  });
};


const closeDashoard = () => {
  chrome.tabs.query( {active:false, currentWindow:true},function(tabs){
    // console.log("tabs::: ",tabs);
    let tabb=[];
    // tabb.push(tabs)
    tabb = tabs;
    chrome.tabs.query( {active:true, currentWindow:true},function(currentTab){
      // console.log("currentTab::: ",currentTab);
      tabb.push(currentTab[0])
      // console.log("tabb ::: ", tabb);
      tabb.forEach(function(el,i){
        // console.log(el.url);
        var matches= el.url.match("/dashboard.html*")
        // console.log("matches : ",matches);
        if  (matches){
        // console.log("matching",matches[0],post_url[3]);
            chrome.tabs.remove(tabb[i].id);
        }
      })
    })
  })
}