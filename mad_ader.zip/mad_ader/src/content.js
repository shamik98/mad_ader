const $ = (jQuery = require("jquery"));
const configData = require("../public/kyubiSettings.json");
const helper = require("./helper.js");
let maInterval = 0;
let processed_posts_count = 0;
let processed_posts_count_Ad = 0;
let processed_div_count = 0;
let maIntervalOCA = 0,
  maInterval1 = 0,
  maInterval2 = 0;

var madAdderBtnClicked = 0;

var processingDiv = 0;  
$(document).ready(function () {

//   Id- drive.bikram@gmail.com Pass- 9832674129
// id-bikram.biswas@tier5.in pass-Test@1234
// id-tier5qa@gmail.com pass-B@7'tew7:av"Q89H
  // alert();
  // console.log("document is ready!!!!!!", $(".settings_overlayPP"));
  if (!$(".settings_overlayPP").length)
    $("body").append('<div class="settings_overlayPP"><span></span></div>'); // Putting overlay view previous comments

  chrome.runtime.onMessage.addListener(cbListener);
  chrome.storage.local.get(["user"], function (res) {
    if (res.user.token !== null && res.user.token !== undefined) {
      var adLib = "www.facebook.com/ads/library/*";
      var currentTab = window.location.href;
      if (currentTab.match(adLib)) {
        doInitAd();
        onElementHeightChange(document.body, function () {
          doInitAd();
        });
      } else {
        // console.log("at home");
        doInit();
        onElementHeightChange(document.body, function () {
          doInit();
        });
      }
    }
  });
});

/**
 * @function callback Handle all requests from background or popup
 * @param {Object} param Payload from background or popup
 * @returns true always for asynchronous nature
 */

function cbListener(param, sender, sendResponse) {
  switch (param.action) {
    case "openAdLibrary":
      openAdLib();
      break;
  }

  return true;
}

function scrollToPos(el) {
  $("html,body").animate(
    {
      scrollTop: $(el).offset().top - 15,
    },
    "slow"
  );
}

// function doProcessingDiv() {
//   let post_count = $('div[mdmsg="Processing"]').length;

//   if (madAdderBtnClicked == 1) { // When MadAddar button is clicked
//     console.log("doProcessingDiv--madAdderBtnClicked",madAdderBtnClicked);
//     setTimeout(doProcessingDiv, 1000);
//     return;
//   }

//   // console.log("doProcessingDiv--hhhhmadAdderBtnClicked",madAdderBtnClicked);
  
//   if (!post_count) {
//     processed_div_count = 0;
//     setTimeout(doProcessingDiv, 1000);
//     return;
//   }
//   if (post_count > processed_div_count) {
//     processDivInterval = setInterval(function () {
//       let divToProcess = $('div[mdmsg="Processing"]');
      
//       if (divToProcess.length) {
//           clearInterval(processDivInterval);
//           checkProcessDivToAttachButton(divToProcess[0]);
//       }
//     }, 2000);
//     processed_div_count = post_count;
//   }

//   setTimeout(doProcessingDiv, 1000);
// }

// function checkProcessDivToAttachButton (currentPost) {
//   if (madAdderBtnClicked == 1) { // When MadAddar button is clicked
//     setTimeout(doProcessingDiv, 3000);
//     return;
//   }
//   let Findthedot = $(currentPost).find(
//     '[aria-label="Actions for this post"]'
//   )[0];
//   $(Findthedot).click();
//   let maInterval11 = setInterval(function () {
        
//     $.each($(".x78zum5.xdt5ytf.x1iyjqo2.x1al4vs7.x6my1t9"), function () {  
//       if (!$(this).is(":hidden")) {
//         popUpmenuBox = $(this);
//       }
//     });
//     PopupMenuBox_children = $(popUpmenuBox[0]).find('[class="x193iq5w xeuugli x13faqbe x1vvkbs x10flsy6 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x41vudc x1f6kntn xvq8zen xk50ysn xzsf02u x1yc453h"]');
//     // for window we are fetching the span
//     if (PopupMenuBox_children.length == 0) {
//       PopupMenuBox_children = $(popUpmenuBox[0]).find('span[dir="auto"]');
//     }
    
//     if ($(PopupMenuBox_children).length) { 
//       clearInterval(maInterval11);
//       let addBtn = false;
//       for (let i = 0; i < PopupMenuBox_children.length; i++) {
//         if (PopupMenuBox_children[i].innerText === "Why am I seeing this ad?") {
//           addBtn = true;
//         }
//       }

//       if (addBtn) {
//         addAdderButton(currentPost);
//       } else {
//         addFalseButton(currentPost);
//       }
//       // let Findthedot = $(currentPost).find('[aria-label="Actions for this post"]')[0];
//       $(Findthedot).click();
//       currentPost.setAttribute("mdmsg", "Evaluated");
//       // doProcessingDiv();
//     } 
//   }, 2000);
// } // End function checkProcessDivToAttachButton (divToProcess) {

function doInit() {
  // let post_count = $('div[data-pagelet^="FeedUnit"]').length;
  let post_count = $('div[class="x1lliihq"]').length;

  if (post_count == 0) {
    post_count = $('[role="article"]').length;
  }
  
  if (!post_count) {
    processed_posts_count = 0;
    // setTimeout(doInit, 500);
    setTimeout(doInit, 1000);
    return;
  }
  if (post_count > processed_posts_count) {
    MenuItemInterval = setInterval(function () {
      // menueButton = $('div[data-pagelet^="FeedUnit"]');
      menueButton = $('div[class="x1lliihq"]');
      if (menueButton.length == 0) {
        menueButton = $('div[role="article"]');
      }
      
      if (menueButton.length) {
          clearInterval(MenuItemInterval);
          attachClickEvent(menueButton);
      }
    // }, 1000);
    }, 2000);
    processed_posts_count = post_count;
  }
}

function doInitAd() {
  console.log("doInitAd");
  var individualAds = $("._7lca").find("._9b9p._99s6");

  let post_count = individualAds.length;
  if (!post_count) {
    processed_posts_count_Ad = 0;
    setTimeout(doInitAd, 500);
    return;
  }
  if (post_count > processed_posts_count_Ad) {
    var MenuItemIntervalAd = setInterval(function () {
      // console.log("individualAds", individualAds);
      if (individualAds.length) {
        clearInterval(MenuItemIntervalAd);
        scrape_ad_lib_ad(individualAds);
      }
    }, 500);
    processed_posts_count_Ad = post_count;
  }
}

function onElementHeightChange(elm, callback) {
  var lastHeight = elm.clientHeight,
    newHeight;
  (function run() {
    newHeight = elm.clientHeight;
    if (lastHeight != newHeight) callback();
    lastHeight = newHeight;

    if (elm.onElementHeightChangeTimer)
      clearTimeout(elm.onElementHeightChangeTimer);

    elm.onElementHeightChangeTimer = setTimeout(run, 200);
  })();
}

const attachClickEvent = (menueButton) => {
  $.each(menueButton, function (el, i) {
    var currentPost = $(this)[0];
    let isAd = currentPost && currentPost.querySelector(
      'a[aria-label="Sponsored"]'
    );
    
    if (isAd == null) {
      // try with href content  
      isAd = currentPost.querySelector("a[href*='/ads/']");
      if (isAd) {
        addAdderButton(currentPost);
        return;
      }
    }
    
    if (isAd == null) {
     
      let adArrChildSpecificDiv = currentPost.querySelectorAll('[class="xu06os2 x1ok221b"]')[1];
      if (!adArrChildSpecificDiv) {
        return;
      }
      
      let adArrChild = adArrChildSpecificDiv.querySelector("a");
      if(adArrChild){
        adArrChild.dispatchEvent(
          new FocusEvent("focusin", {
            view: window,
            bubbles: true,
            cancelable: true,
          })
        );
        setTimeout(()=>{
          if(adArrChild.getAttribute("href").includes("/ads/")){
            addAdderButton(currentPost);
          }
        }, 1000)
      }
      return;
    }
  });
};

// const attachClickEventBkp = (menueButton) => {
//   $.each(menueButton, function (el, i) {
//     var currentPost = $(this)[0];
//     let isAd = currentPost && currentPost.querySelector(
//       'a[aria-label="Sponsored" ]'
//     );

//     if (isAd == null) {
//       let allA = currentPost.querySelectorAll("a[href^='/ads/about']")[0]; 
//       let adArrChild = currentPost && currentPost.querySelector(
//         "a[aria-label='label']"
//       );

//       if (adArrChild === null) {
//         adArrChild = currentPost.querySelectorAll("a[href='#']")[0];
//       }
      
//       if (adArrChild === null) {
//         let adArrChildAnchor = currentPost && currentPost.querySelectorAll("a[href='#']");
//         adArrChild = adArrChildAnchor[0];
//       }

//       if (adArrChild != null) {
//           adArrChild = adArrChild.firstChild && adArrChild.firstChild.firstChild && adArrChild.firstChild.firstChild.firstChild
//           let adArr = [];
//           $(adArrChild).children().each(function () {
//             if (!($(this).css('display') == 'none') && !($(this).css('position') == 'absolute')) {
//               adArr.push($(this)[0].textContent)
//             }
//           })
//           //==================================================================================================================
//           // New Code for adding mad adder button
//           // console.log("adArrLength", adArr.length);
//           if (adArr.length != 1) {
//             return;
//           }
//           checkToAddAdderButton(currentPost);
//           console.log("currentPost", currentPost);
//           // End of New code for adding Mad Adder Button
//           //==================================================================================================================
//           if (adArr.length) {
//             addAdderButton(currentPost);
//             return;
//           }

//           adArr = adArr.toString().replace(/[\,]/g, "").toLocaleLowerCase().trim();

//           let sponsoredText = "sponsored";
//           var temp2 = [];
//           for (let j of adArr) {
//             const index = sponsoredText.indexOf(j);
//             if (index > -1) {
//               temp2[index] = j;
//               if (j == "o")
//                 sponsoredText = sponsoredText.replace("o", "O");
//               if (j == "s")
//                 sponsoredText = sponsoredText.replace("s", "S");
//             }
//           }
//           var temp = temp2.toString().replace(/[\,]/g, "")
//         // } // End if (adArr.split(" ").length == 1) {
        
//         if (temp.length > 0 && temp.toLowerCase().trim() == "sponsored") {
//           isAd = currentPost.querySelector("a[href*='/ads']") ?
//             currentPost.querySelector("a[href*='/ads']") :
//             currentPost.querySelector("a[href='#']");
//         }
        
//       }
//     }

//     if (isAd == null) {
//       // try with href content  
//       isAd = currentPost.querySelector("a[href*='/ads/']")
//     }

//     if (isAd) {
//       addAdderButton(currentPost);
//     }
//   });
// };


// const attachClickEvent = (menueButton) => {
//   $(menueButton).each(function () {
//     let currentPost = $(this);
//     //console.log("currentPost:: ", currentPost);
//     $(this)
//       .find(".j1lvzwm4.stjgntxs.ni8dbmo4.q9uorilb.gpro0wi8")
//       .children()
//       .each(function () {
//         let w;
//         if ($(this).text()) {
//           w = $(this).text();
//           // console.log("w :: ", w);
//         }
//         // console.log(typeof w);
//         if (
//           w.indexOf("S") > -1 &&
//           w.indexOf("p") > -1 &&
//           w.indexOf("o") > -1 &&
//           w.indexOf("n") > -1 &&
//           w.indexOf("s") > -1 &&
//           w.indexOf("o") > -1 &&
//           w.indexOf("r") > -1 &&
//           w.indexOf("e") > -1 &&
//           w.indexOf("d") > -1
//         ) {
//           let hrefs = currentPost
//             .find(".j1lvzwm4.stjgntxs.ni8dbmo4.q9uorilb.gpro0wi8")
//             .parents("a")
//             .attr("href");
//           if (hrefs != "#" || hrefs != null) {
//             hrefAdds = hrefs.includes("ads");
//             if (hrefAdds == true) {
//               console.log("hrefs: ", hrefs);
//               // console.log("hrefAdds: ", hrefAdds);
//               addAdderButton(currentPost);
//             }
//           }
//         } else {
//           // console.log("no");
//         }
//       });
//   });

//   // $.each(menueButton, function (el, i) {
//   //   // console.log(menueButton);
//   //   var currentPost = $(this)[0];
//   //   let isAd;
//   //   if (isAd == null) {
//   //     let adArr = $(this)[0].querySelectorAll(
//   //       ".b6zbclly.myohyog2.l9j0dhe7.aenfhxwr.l94mrbxd.ihxqhq3m.nc684nl6.t5a262vz.sdhka5h4:not([style])"
//   //     );
//   //     let magicWord = "";
//   //     for (let indx = 0; indx < adArr.length; indx++) {
//   //       const w = adArr[indx].textContent;
//   //       if (w.length > 1) continue;
//   //       magicWord += w;
//   //     }
//   //     console.log("magicWord1 : ", magicWord);
//   //     if (magicWord.length > 0 && magicWord.toLowerCase() == "sponsored") {
//   //       isAd = $(this)[0].querySelector("a[href*='/ads']")
//   //         ? $(this)[0].querySelector("a[href*='/ads']")
//   //         : $(this)[0].querySelector("a[href='#']");
//   //     }
//   //   }
//   //   console.log("is Add at 2nd chance ???? ", isAd);
//   //   if (isAd == null) {
//   //     let adArr = $(this)[0].querySelectorAll(
//   //       ".b6zbclly.myohyog2.l9j0dhe7.aenfhxwr.l94mrbxd.ihxqhq3m.nc684nl6.t5a262vz.sdhka5h4:not([style])"
//   //     );
//   //     let magicWord = "";
//   //     if (adArr[0] != undefined) magicWord = adArr[0].textContent[0];
//   //     for (let indx = 1; indx < adArr.length; indx++) {
//   //       const w = adArr[indx].textContent;
//   //       console.log("each text : ", w);
//   //       if (w.length > 1) continue;
//   //       magicWord += w;
//   //     }
//   //     console.log("magicword2 : ", magicWord);
//   //     if (magicWord.length > 0 && magicWord.toLowerCase() == "sponsored") {
//   //       isAd = $(this)[0].querySelector("a[href*='/ads']")
//   //         ? $(this)[0].querySelector("a[href*='/ads']")
//   //         : $(this)[0].querySelector("a[href='#']");
//   //     }
//   //   }
//   //   console.log("is Add at 3rd chance ???? ", isAd);

//   //   // if(isAd == null) {
//   //   //   // try with href content
//   //   //   isAd = $(this)[0].querySelector("a[href*='/ads']")
//   //   // }
//   //   // console.log("is Add 1st chance???? ", isAd);
//   //   if (isAd == null)
//   //     isAd = $(this)[0].querySelector("[aria-label='Sponsored']");
//   //   // console.log("is Add at 4th chance ???? ", isAd);

//   //   if (isAd == null) {
//   //     let adArr = $(this)[0].querySelectorAll(
//   //       ".b6zbclly.myohyog2.l9j0dhe7.aenfhxwr.l94mrbxd.ihxqhq3m.nc684nl6.t5a262vz.sdhka5h4:not([style])"
//   //     );
//   //     let magicWord = "";
//   //     if (adArr[0] != undefined) magicWord = adArr[0].textContent[0];
//   //     for (let indx = 1; indx < adArr.length; indx++) {
//   //       const w = adArr[indx].textContent;
//   //       if (w.length > 1) continue;
//   //       magicWord += w;
//   //     }
//   //     // console.log("magicword : ", magicWord == "--S-po-----n---so----r-ed---");
//   //     // console.log("magicword : ", magicWord == "---S-po-----n---so----r-ed---");
//   //     if (
//   //       magicWord.length > 0 &&
//   //       (magicWord == "--S-po-----n---so----r-ed---" ||
//   //         magicWord == "---S-po-----n---so----r-ed---")
//   //     ) {
//   //       isAd = $(this)[0].querySelector("a[href*='/ads']")
//   //         ? $(this)[0].querySelector("a[href*='/ads']")
//   //         : $(this)[0].querySelector("a[href='#']");
//   //     }
//   //   }

//   //   // console.log("is Add at 4th chance ???? ", isAd);
//   //   if (isAd) {
//   //     maInterval = setInterval(function () {
//   //       // console.log("current post : " , currentPost);
//   //       addAdderButton(currentPost);
//   //       // }
//   //     }, 800);
//   //   }
//   // });
// };



const addAdderButton = (currentPost) => {
  var postHead = $(currentPost).find('[class^="x1iyjqo2"]')[0];
  var sideButton = $($(postHead).parent()[0]).children();
  
  var already_exists;
  Array.prototype.forEach.call(sideButton, (child) => {
   
    if ($(child).hasClass("adderButton")) {
      already_exists = true;
    }
  });
 
  if (already_exists) return;
  
  $(
    `<div style="margin-right:20px;margin-top:7px" class="adderButton"><button class="confirm appName"> + ` +
    configData.appName +
    `</button>
        </div>`
  ).insertAfter(postHead);
  $(".appName").click(function () {
    clearInterval(maInterval);
    clearInterval(maInterval1);    
    // const postObjElArr = $(this).closest('div[class="j83agx80 cbu4d94t"]'); // commented by ankur
    const postObjElArr = $(this).closest('div[class="x1n2onr6 x1ja2u2z"]');
    let postDescription = $(postObjElArr[0]).find('[data-ad-preview="message"]');

    if ($(postDescription).length) {
      var seeMore = $(postDescription[0]).find('div[class="x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f"]');
      
      if ($(seeMore).length) {
        $(seeMore[0]).click();
      }
    }
    showPopup(postObjElArr);
  });
};

const collectWhyAd = (postObjElArr, popupWhy, attempt=1, reasonsOfAdsText = '') => {
  var maInterval = setInterval(function () {
    const reasonsOfAds = $($(popupWhy)[0]).find(
      'div[data-visualcompletion="ignore-dynamic"]'
    );

    var responseHeader = 'NA';

    if (reasonsOfAds.length > 0) { // here we are checking whether some div appear or not
      clearInterval(maInterval);
      if (attempt == 1) {
        var reasonOfAdsAdviserChoicesDiv;
          for (var i = 0; i < reasonsOfAds.length - 2; ++i) {
              if ($(reasonsOfAds[i]).text().trim().includes("Advertiser choices")) {
                responseHeader = $(reasonsOfAds[i]).text().trim();
                reasonOfAdsAdviserChoicesDiv = $(reasonsOfAds[i]).find('div[role="button"]');
                reasonsOfAdsText += $(reasonsOfAds[i]).text().trim();
                break;
              } // end if ($(reasonsOfAds[i]).text().trim().includes("Advertiser choices")) {
          } // for (var i = 0; i < reasonsOfAds.length - 2; ++i) {
          // console
          if (responseHeader.includes("Advertiser choices")) {
            // console.log(";;;;;;;;;;;;;;;;;;")
            collectReasonOfAdsAdviserChoices(postObjElArr, popupWhy, reasonsOfAds, reasonOfAdsAdviserChoicesDiv, reasonsOfAdsText);
            return;
          }
      }
    
      if (attempt == 2) {
        var reasonOfAdsYourActivityDiv;
        for (var i = 0; i < reasonsOfAds.length - 2; ++i) {
            if ($(reasonsOfAds[i]).text().trim().includes("Your activity")) {
              responseHeader = $(reasonsOfAds[i]).text().trim();
              reasonOfAdsYourActivityDiv = $(reasonsOfAds[i]).find('div[role="button"]');
              reasonsOfAdsText += $(reasonsOfAds[i]).text().trim();
              break;
            } // end if ($(reasonsOfAds[i]).text().trim().includes("Advertiser choices")) {
        } // for (var i = 0; i < reasonsOfAds.length - 2; ++i) {

        if (responseHeader.includes("Your activity")) {
          collectReasonOfAdsYourActivity(postObjElArr, popupWhy, reasonsOfAds, reasonOfAdsYourActivityDiv, reasonsOfAdsText);
          return;
        } else {
          // console.log("llllllllllllllllllll")
          const closeButton = $($(popupWhy)[0]).find('[aria-label="Close"]')[0];
          if (reasonsOfAds) {
            $(closeButton)[0].click();
            setTimeout(function () {
              saveAddDatas(postObjElArr, reasonsOfAdsText);
            }, 500);
          }
          return;
        }
      }

    } // End if (reasonsOfAds.length > 0) {


  
  }, 2000);
  
  // let reasonsOfAdsText = "";
  // let uniqueReasonOfAds = new Set();
  // for (var i = 0; i < reasonsOfAds.length - 2; ++i) {
  //   // console.log("reasonsOfAds["+i+"] :: ", $(reasonsOfAds[i]).text());
  //   uniqueReasonOfAds.add($(reasonsOfAds[i]).text().trim());
  //   //reasonsOfAdsText += " " + (i + 1) + ") " + $(reasonsOfAds[i]).text();
  // }
  // let index = 1;
  // uniqueReasonOfAds.forEach(function (value) {
  //   reasonsOfAdsText += " " + index++ + ") " + value;
  // });

  // const closeButton = $($(popupWhy)[0]).find('[aria-label="Close"]')[0];
  // if (reasonsOfAds) {
  //   $(closeButton)[0].click();
  //   setTimeout(function () {
  //     saveAddDatas(postObjElArr, reasonsOfAdsText);
  //   }, 500);
  // }
};

// this function is used to collect the reasons for Your Activity
const collectReasonOfAdsYourActivity = (postObjElArr, popupWhy, reasonsOfAds, reasonOfAdsYourActivityDiv, reasonsOfAdsText) => {
  reasonOfAdsYourActivityDiv.click();
  var maInterval = setInterval(function () {    
    let divOfReasonPopup = $('div[class="x1uvtmcs x4k7w5x x1h91t0o x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1n2onr6 x1qrby5j x1jfb8zj"]');
    // let divOfReasonPopup = $('div[role="dialog"]').last();
    if (divOfReasonPopup.length > 0) {
      clearInterval(maInterval);
      var allDivhavingReason = $(divOfReasonPopup[1]).find('div[class="x78zum5 xdt5ytf xz62fqu x16ldp7u"]');
      for (var i = 0; i < allDivhavingReason.length; i++) {
        let k = i+1;
        reasonsOfAdsText += " "+k+") " + $(allDivhavingReason[i]).text().trim();
      }
    }
    var popupWhy = $('div[role="dialog"]').last();
    $(popupWhy[0]).find('div[aria-label="Close"]').click();
    setTimeout(function () {
      saveAddDatas(postObjElArr, reasonsOfAdsText);
    }, 500);
  }, 1000);
}

// this function is used to collect the reasons for Advisory Choice
const collectReasonOfAdsAdviserChoices = (postObjElArr, popupWhy, reasonsOfAds, reasonOfAdsAdviserChoices, reasonsOfAdsText) => { 
  reasonOfAdsAdviserChoices.click();
  var maInterval = setInterval(function () {    
    let divOfReasonPopup = $('div[class="x1uvtmcs x4k7w5x x1h91t0o x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1n2onr6 x1qrby5j x1jfb8zj"]');
    // let divOfReasonPopup = $('div[role="dialog"]').last();
    if (divOfReasonPopup.length > 0) {
      clearInterval(maInterval);
      var allDivhavingReason = $(divOfReasonPopup[1]).find('div[class="x78zum5 xdt5ytf xz62fqu x16ldp7u"]');
      for (var i = 0; i < allDivhavingReason.length; i++) {
        // console.log("lll---", $(allDivhavingReason[i]).text().trim());
        let k = i+1;
        reasonsOfAdsText += " "+k+") " + $(allDivhavingReason[i]).text().trim();
      }
    }

    var popupWhy = $('div[role="dialog"]').last();
    $(popupWhy[0]).find('div[aria-label="Back"]').click();
    setTimeout(function () {
      var maInterval2 = setInterval(function () {
        var popupWhy = $('div[role="dialog"]').last(); //$(".l081gc3l.ip4hrkex")
        if ($(popupWhy)[0] && $(popupWhy[0]).find('div[aria-label="Loading..."]').length == 0) {
          clearInterval(maInterval2);
          collectWhyAd(postObjElArr, popupWhy, 2, reasonsOfAdsText);
        }
      }, 1000);
    }, 2000);
  }, 1000);
}




// const collectWhyAdBkp = (postObjElArr, popupWhy) => {

//   const reasonsOfAds = $($(popupWhy)[0]).find(
//     'div[data-visualcompletion="ignore-dynamic"]'
//   );
  
//   let reasonsOfAdsText = "";
//   let uniqueReasonOfAds = new Set();
//   for (var i = 0; i < reasonsOfAds.length - 2; ++i) {
//     // console.log("reasonsOfAds["+i+"] :: ", $(reasonsOfAds[i]).text());
//     uniqueReasonOfAds.add($(reasonsOfAds[i]).text().trim());
//     //reasonsOfAdsText += " " + (i + 1) + ") " + $(reasonsOfAds[i]).text();
//   }
//   let index = 1;
//   uniqueReasonOfAds.forEach(function (value) {
//     reasonsOfAdsText += " " + index++ + ") " + value;
//   });

//   const closeButton = $($(popupWhy)[0]).find('[aria-label="Close"]')[0];
//   if (reasonsOfAds) {
//     $(closeButton)[0].click();
//     setTimeout(function () {
//       saveAddDatas(postObjElArr, reasonsOfAdsText);
//     }, 500);
//   }
// };

const saveAddDatas = async (postObjElArr, reasonsOfAds) => {

  const video = $(postObjElArr).find("video").toArray();
  const videoSrc = $(video).attr("src");
  const isVideoAd = 0 < video.length;

  var adImage = '';
  if ($($(postObjElArr).find('img[class="x1ey2m1c xds687c x5yr21d x10l6tqk x17qophe x13vifvy xh8yej3 xl1xv1r"]')[0])) {
    adImage = $($(postObjElArr).find('img[class="x1ey2m1c xds687c x5yr21d x10l6tqk x17qophe x13vifvy xh8yej3 xl1xv1r"]')[0]).attr("src");
  }
  
  adImage =
    adImage ||
    (Array.from(
      document.querySelectorAll(
        "div.ojkyduve.ggysqto6 > div > div > section > ul > li > div > div > div > a > div > img"
      )
    ).map(function (t) {
      return t.getAttribute("src");
    }) || [])[0];
  
  const cPageName = $(postObjElArr).find('[class^="x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f"]')
  const companyPageName = cPageName[0] ? cPageName[0].innerText : "",
  companyUrl = cPageName.attr("href");

  const companyLogo = $($(postObjElArr).find("image")[0]).attr("xlink:href");

  const postCopy = (
    $(postObjElArr).find('[data-ad-preview="message"]').text() || ""
  ).trim();

  const destinationUrl = $(postObjElArr)
    .find('[type="nested/pressable"] a')
    .attr("href");

  var headline = ($(postObjElArr).find('span[class="b6ax4al1 lq84ybu9 hf30pyar om3e55n1"]').text() || "").trim();
  // console.log("headline ===== 711", headline);

  if (headline.length < 1) {
    // console.log("postObjElArr====== ", postObjElArr);
    // console.log("postObjElArr====== ", $(postObjElArr).find('a[role="link"]'));
    headline = $($(postObjElArr).find('span[dir="auto"]')[24]).text().trim();
  }
  // console.log("headline ===== 716", headline);

  if (headline.split(" ").length < 3) {
    headline = "NA"
  }
 
  const smalltext = ($(postObjElArr).find(".qzhwtbm6.knvmm38d .oi732d6d.ik7dh3pa.d2edcug0.qv66sw1b.c1et5uql.a8c37x1j.muag1w35.enqfppq2.jq4qci2q.a3bd9o3v.knj5qynh.m9osqain.hzawbc8m.ni8dbmo4.stjgntxs.ltmttdrg.g0qnabr5").text() || "").trim();
  
  const shop = $(postObjElArr).find(".bi6gxh9e.sqxagodl span").text();

  const buttonText = $(postObjElArr).find(".rq0escxv.l9j0dhe7.du4w35lb.d2edcug0.j5wkysh0.hytbnt81 span").text();
  
  let post_url_dev = $(postObjElArr).find('div[class="x1vjfegm"]');
  var post_url = "NA";
  var gotPostUrl = false;
  
  for (let i = 0; i < post_url_dev.length; i++) {
    var post_url_dev_a = $(post_url_dev[i]).find('a');
    for (let k = 0; k < post_url_dev_a.length; k++) {
      if (!post_url_dev_a[k].href.includes("https://facebook.com/?")) { // Url found
        gotPostUrl = true;
        post_url = post_url_dev_a[k].href;
        break;
      }
    } // End for (let k = 0; k < post_url_dev.length; k++) {
    if (gotPostUrl) {
      break;
    }
  } // End for (let i = 0; i < post_url_dev.length; i++) {
  
  
  if (!post_url) {
    post_url = $(postObjElArr).find("div.ni8dbmo4 >a").attr("href");
  }
  // console.log('posturl1:'+post_url);
  if (post_url == undefined || post_url == "undefined") {
    post_url = $(postObjElArr).find("div.tkr6xdv7 object >a").attr("href");
  }

  let key = "hmd_" + new Date().toISOString().replace(".", "_");

  // console.log("CommentShare : ", $(postObjElArr).find('div[class="gtad4xkn"]'));
  // const CommentShare = $(postObjElArr).find('div[class="xnfveip"]');
  // const CommentShare = $(postObjElArr).find('span[class="x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x3x7a5m x6prxxf xvq8zen xo1l8bm xi81zsa"]');
  // const CommentShare = $(postObjElArr).find('span[class="x193iq5w xeuugli x13faqbe x1vvkbs x10flsy6 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x41vudc x1f6kntn xvq8zen xo1l8bm xi81zsa"]');
  let CommentShare = $(postObjElArr).find('span[class="x193iq5w xeuugli x13faqbe x1vvkbs x10flsy6 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x41vudc x6prxxf xvq8zen xo1l8bm xi81zsa"]');
  console.log("postObjElArr============", postObjElArr);
  console.log("CommentShare=========================", CommentShare);
  if (CommentShare.length == 0) {
    CommentShare = $(postObjElArr).find('span[class="x4k7w5x x1h91t0o x1h9r5lt x1jfb8zj xv2umb2 x1beo9mf xaigb6o x12ejxvf x3igimt xarpa2k xedcshv x1lytzrv x1t2pt76 x7ja8zs x1qrby5j"]');
  }

  console.log("CommentShare========================= 2", CommentShare);
  
  var 
      comments = '',
      shares = 0;
      
  let isComment=false;
  let commentEle=null;
  CommentShare.each(function () {
    
    let element = $(this);
    
    if (element[0].innerText && element[0].innerText.toLowerCase().includes('comment') ){ 
     
      comments = element[0].innerText.split(" ")[0]
      isComment=true
      
      commentEle=element;
    };
      

    if (element[0].innerText && element[0].innerText.toLowerCase().includes('share')) {
      shares = element[0].innerText.split(" ")[0]
    };
      
  })

  console.log("comments============", comments);
  console.log("shares============", shares);
  console.log("commentEle============", commentEle);
  // return;



  const feelings = reactions(postObjElArr);
  const like = feelings && feelings.has("Like") ? feelings.get("Like") : 0,
    angry = feelings && feelings.has("Angry") ? feelings.get("Angry") : 0,
    love = feelings && feelings.has("Love") ? feelings.get("Love") : 0,
    sad = feelings && feelings.has("Sad") ? feelings.get("Sad") : 0,
    wow = feelings && feelings.has("Wow") ? feelings.get("Wow") : 0,
    care = feelings && feelings.has("Care") ? feelings.get("Care") : 0,
    haha = feelings && feelings.has("Haha") ? feelings.get("Haha") : 0;

  var finalData = {
    companyPageName: companyPageName,
    companyLogo: companyLogo,
    companyUrl: companyUrl,
    postCopy: postCopy,
    destinationUrl: destinationUrl,
    isVideo: isVideoAd,
    adImage: adImage,
    headline: headline,
    smalltext: smalltext,
    shop: shop,
    buttonText: buttonText,
    postUrl: post_url,
    comments: comments,
    likes: $(postObjElArr).find(".gpro0wi8.pcp91wgn").text(),
    shares: shares,
    views: null,
    videoSrc: videoSrc,
    key: key,
    seenAt: new Date().toISOString(),
    addedAt: new Date().toISOString(),
    isNewUi: !0,
    like: like,
    angry: angry,
    love: love,
    sad: sad,
    wow: wow,
    care: care,
    haha: haha,
    reasonsOfAds: reasonsOfAds,
    oldestCommentAge: "N/A"
  };

  reactionGrab(finalData, key, postObjElArr, CommentShare, isComment,commentEle);
  // openCommentSection(finalData, key, postObjElArr, CommentShare, isComment)
}; // 

const priorityLevel = (time) => {
  var priority;
  switch (time) {
    case "s":
      priority = 1;
      break;
    case "m":
      priority = 2;
      break;
    case "h":
      priority = 3;
      break;
    case "d":
      priority = 4;
      break;
    case "w":
      priority = 5;
      break;

    case "y":
      priority = 6;
      break;

    default:
      priority = 0;
      break;
  }

  return priority;
};

async function viewPreviousComments(postObjElArr, callback) {
  // console.log("viewPreviousComments===");
  var intrvl = setInterval(async function () {
    clickLoadMoreComments(postObjElArr, function (bool) {
      if (bool) {
        clearInterval(intrvl);
        callback();
      }
    });
  }, 1000);
}

function clickLoadMoreComments(postObjElArr, cb) {
  // console.log("clickLoadMoreComments===");
  $(".textChanging").html(
    "Initialized " +
    configData.appName +
    ".<br> " +
    configData.appName +
    " is running.<br> Fetched 'why i'm seeing this ad' data. <br> Grabed all reaction Counts.<br>" +
    configData.appName +
    " is scanning all comments<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
  );
  // const pageNext = $(document).find('[id^="see_next"]');
  // console.log("postObjElArr", $($(postObjElArr).find(".k0kqjr44.laatuukc")[0]).children().eq(5)[0]);
  const viewMoreCommentBlock = $($(postObjElArr).find(".k0kqjr44.laatuukc")[0])
    .children()
    .eq(5)
    .children();
  const viewMorecomment = $(viewMoreCommentBlock.eq(0)[0])
    .children()
    .eq(1)
    .children();
  const noOfLoadedComment = $(viewMoreCommentBlock.eq(1)[0])
    .text()
    .split(" of ")[0];

  // console.log("viewMoreCommentBlock===", viewMoreCommentBlock);
  // console.log("viewMorecomment===", viewMorecomment);
  // console.log("noOfLoadedComment===", noOfLoadedComment);

  if (parseInt(noOfLoadedComment) < 200) {
    if (parseInt(noOfLoadedComment) > 40) {
      $(".textChanging").html(
        "Initialized " +
        configData.appName +
        ".<br> " +
        configData.appName +
        " is running.<br> Fetched 'why i'm seeing this ad' data. <br> Grabed all reaction Counts.<br>Please wait a while and don't close or refresh the page"
      );
    }
    if (parseInt(noOfLoadedComment) > 100) {
      $(".textChanging").html(
        "Initialized " +
        configData.appName +
        ".<br> " +
        configData.appName +
        " is running.<br> Fetched 'why i'm seeing this ad' data. <br> Grabed all reaction Counts.<br>" +
        configData.appName +
        " is scanning all comments<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
      );
    }
    if (parseInt(noOfLoadedComment) > 150) {
      $(".textChanging").html(
        "Initialized " +
        configData.appName +
        ".<br> " +
        configData.appName +
        " is running.<br> Fetched 'why i'm seeing this ad' data. <br> Grabed all reaction Counts.<br>We are almost there.<br>" +
        configData.appName +
        " is scanning all comments<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div>"
      );
    }
    $(viewMorecomment)[0].click();
    if ($(viewMorecomment)[0] === undefined) {
      cb(true);
    }
  } else cb(true);
}

const saveFinalData = async (finalData, key, elem = null) => {
  // console.log('saveFinalData=====================', $('div[aria-label="Close"]'));
 
  // console.log("elem in save : ", elem);
  const totalAds = await helper.getAdData();
  var find_link = $(elem).find(".m8urbbhe.fv962s72");
  // console.log("final data : ", find_link[0]);
  if (find_link.length) {
    // console.log("final data : ", $(find_link[0]).hasClass('mad_button_header'));

    if ($(find_link[0]).hasClass("mad_button_header")) {
      const madAder = $(elem).find(".madAder")[0];
      // console.log("madader", madAder);
      const plus_sign = $(madAder).find("span")[0];
      plus_sign.remove();
      $($(madAder).find("button")[0]).prop("disabled", true);
    }
  }

  let isSaved;
  if (!totalAds.length) {
    totalAds.push(finalData);
    isSaved = await helper.saveAdData(totalAds);
    // $(".settings_overlay").css("display", "none");
    // console.log("vvvvvvv-------------",$('div[aria-label="Close"]')[0]);
    if (isSaved) {
      madAdderBtnClicked = 0;
      // $($('div[aria-label="Close"]')[0]).click();
      $(".settings_overlayPP").css("display", "none");
      if (elem != null) {
        const appName = $(elem).find(".appName");
        const adderButton = $(elem).find(".adderButton");
        
        $(appName).text("Added");
        $(appName).attr("disabled", "disabled");
      }
      var successPop =
        '<div class="successpopupsection" style="position: fixed; background: ' +
        chrome.runtime.getURL("../images/popupBack.png") +
        ' no-repeat; top: 0; transform: translate(-50%,0%);  left: 50%; background: #1a40c9; background-size: cover; margin: 0px; padding: 18px 30px; width: 448px; border-radius: 10px; text-align: center; z-index: 999;"><p style="font-size: 18px; margin-bottom: 25px; color: #fff; text-align: left;"> Added  ' +
        finalData.companyPageName +
        ' </p><button class="confirmBtn" id="subBtn">Ok</button></div>';
      $("body").append(successPop);

      

      $(document).on("click", "#subBtn", function (e) {
        e.preventDefault();
        $(".confirmpopupsection").remove();
        $(".successpopupsection").remove();
      });

      $($('div[aria-label="Close"]')[0]).click(); // to close popup
      $($('div[aria-label="Close"]')[20]).click(); // to close popup
    }
  } else {
    // const filteredNewSettings = totalAds.filter(obj => obj.post_url !== postUrl);
    const newSettings = [...totalAds, finalData];
    // console.log("newSettings : ", newSettings);
    isSaved = await helper.saveAdData(newSettings);
    // console.log("isSaved : ", isSaved);

    if (isSaved) {
      madAdderBtnClicked = 0;
      // $($('div[aria-label="Close"]')[0]).click();
      $(".settings_overlayPP").css("display", "none");
      if (elem != null) {
        const appName = $(elem).find(".appName");
        const adderButton = $(elem).find(".adderButton");
        
        $(appName).text("Added");
        $(appName).attr("disabled", "disabled");
      }
      var successPop =
        '<div class="successpopupsection" style="position: fixed; background: ' +
        chrome.runtime.getURL("../images/popupBack.png") +
        ' no-repeat; top: 0; transform: translate(-50%,0%);  left: 50%; background: #1a40c9; background-size: cover; margin: 0px; padding: 18px 30px; width: 448px; border-radius: 10px; text-align: center; z-index: 999;"><p style="font-size: 18px; margin-bottom: 25px; color: #fff; text-align: left;"> Added  ' +
        finalData.companyPageName +
        ' </p><button class="confirmBtn" id="subBtn">Ok</button></div>';
      $("body").append(successPop);

      

      $(document).on("click", "#subBtn", function (e) {
        e.preventDefault();
        madAdderBtnClicked = 0; // it is 0 means the divs can be proccessed
        $(".confirmpopupsection").remove();
        $(".successpopupsection").remove();
      });

      $($('div[aria-label="Close"]')[0]).click(); // to close popup
      $($('div[aria-label="Close"]')[20]).click(); // to close popup
    }
  }
};

const reactions = (postObjElArr) => {
  var e = new Map();
  try {
    for (
      var r = postObjElArr.querySelectorAll("span[role*='toolbar'] div"), n = 0;
      n < r.length;
      n++
    )
      try {
        var a = (r[n].getAttribute("aria-label") || "").split(":");
        // console.log("a : ", a);
        e.set(a[0], a[1].split(" ")[1]);
      } catch (postObjElArr) { }
  } catch (postObjElArr) { }
  return e;
};

const scrape_ad_lib_ad = (individualAds) => {
  
  $.each(individualAds, function (index, value) {
    // console.log("individualAds...", value);
    // var find_link = $(value).find(".m8urbbhe.fv962s72")[0];
    var find_link = $(value).find(".x1cy8zhl.x78zum5.xyamay9.x1pi30zi.x18d9i69.x1swvt13.x1n2onr6")[0];
    if (!$(find_link).hasClass("mad_button_header")) {
      $(find_link).addClass("mad_button_header");
      const mad_adeer_btn =
        `<div class="madAder"> 
      <button class="confirm confirm-lib adMadAder">
      <img alt="" style="max-width: 16px; vertical-align: middle" src="  ` +
        chrome.runtime.getURL(configData.logo.large_icon) +
        ` " />
      <span>+</span> </button>
      </div>`;
      var parser = new DOMParser();
      var doc = parser.parseFromString(mad_adeer_btn, "text/html");
      find_link.append(doc.body.firstChild);
    }
  });

  $(".adMadAder").click(function () {
    const adBlock = $(this)[0].closest(".xh8yej3");
    // console.log("adBlock=======", adBlock);
    showPopup(adBlock);
  });
};

const getFinaldataForAd = (adBlock) => {
  var videoSrc,
    // r = new Date().toISOString(),
    // n = $(adBlock).find('[class="dgpf1xc5"] a'),
    n = $(adBlock).find('[class="x1rg5ohu x67bb7w"] a'),
    companyPageName = n[0] ? n[0].innerText : "",
    companyUrl = n.attr("href"),
    companyLogo = $(adBlock)
      .find('[class^="_3qn7 _61-0 _2fyi _3qng"] img')
      .attr("src"),
    postCopy = $(adBlock).find('[class^="_7jyr"]').text().trim(),
    headline = $($(adBlock).find("._8nsi._8nqp")).text(),
    adImage = $($(adBlock).find('[class="x6ikm8r x10wlt62"] a')[1]).find('img'); //.length ? adimage[0].getAttribute("src") : "",
    adImage = adImage.length ? adImage[0].getAttribute("src") : "";
    

    // console.log("n", n);
  (destinationUrl = $(adBlock).find('[class="x6ikm8r x10wlt62"] a')[1]
    ? $(adBlock).find('[class="x6ikm8r x10wlt62"] a')[1].getAttribute("href")
    : ""),
  (video = $($(adBlock).find(".mfclru0v")[5]).find('video')[0]
    ? $($(adBlock).find(".mfclru0v")[5]).find('video')[0].getAttribute("src")
    : "");
  
  // adImage = adImage.length ? adImage[0].getAttribute("src") : "";
  // console.log("adImage : ", adImage);
  if (headline == "")
    headline = $(
      $(adBlock).find(
        "ta68dy8c.kpwa50dg.lk0hwhjd.cmg2g80i.hf30pyar.lq84ybu9"
      )
    ).text();

    
  const keyLab = "hmd_" + new Date().toISOString().replace(".", "_");
  let finalData = {
    companyPageName: companyPageName,
    companyLogo: companyLogo,
    companyUrl: companyUrl,
    postCopy: postCopy,
    destinationUrl: destinationUrl,
    isVideo: $($(adBlock).find(".iajz466s")[1]).find("video")[0] ? true : false,
    adImage: adImage,
    headline: headline,
    smalltext: headline,
    postUrl: destinationUrl,
    videoSrc: video,
    key: keyLab,
    addedAt: new Date().toISOString(),
    like: 0,
    likes: 0,
    love: 0,
    care: 0,
    haha: 0,
    sad: 0,
    angry: 0,
    wow: 0,
    shares: 0,
    comments: 0,
    reasonsOfAds: 0,
  };
  saveFinalData(finalData, keyLab, adBlock);
};

const showPopup = (postObjElArr = null) => {
  madAdderBtnClicked = 1; // it is 1 means the posts can not be proccessed
  var parser = new DOMParser();
  var confirmPop =
    '<div class="confirmpopupsection" style="position: fixed; background: ' +
    chrome.runtime.getURL("../images/popupBack.png") +
    ' no-repeat; top: 0; transform: translate(-50%,0%);  left: 50%; background: #1a40c9; background-size: cover; margin: 0px; padding: 18px 30px; width: 448px; border-radius: 10px; text-align: center; z-index: 999;"><p style="font-size: 18px; margin-bottom: 25px; color: #fff; text-align: left;"> Are you sure you want to Add this Facebook Ads to your Collection ? </p><button class="confirmBtn" id="confirmBtn" style="margin: 0 10px;">Yes</button><button class="cancelBtn" id="cancelBtn" style="margin: 0 10px;">No</button></div>';
  // $("body").append(confirmPop);
  var doc = parser.parseFromString(confirmPop, "text/html");
  $("body").prepend(doc.body.firstChild);

  $(document).on("click", "#cancelBtn", function (e) {
    e.preventDefault();
    madAdderBtnClicked = 0; // it is 0 means the posts can be proccessed
    $(".confirmpopupsection").remove();
    $(".successpopupsection").remove();
  });

  $("#confirmBtn").click((e) => {
    e.preventDefault();
    madAdderBtnClicked = 1; // it is 1 means the posts can not be proccessed
    $(".settings_overlayPP > span").html(
      " <div class='textChanging'>Initializing " +
      configData.appName +
      "<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page.</div>"
    );
    $(".settings_overlayPP").css("display", "block"); // temporary comment

    $(".confirmpopupsection").remove();
    var adLib = "www.facebook.com/ads/library/*";
    var currentTab = window.location.href;
    // console.log("currentTab==", currentTab);
   
    if (currentTab.match(adLib)) {
      getFinaldataForAd(postObjElArr);
    } else { 
      let Findthedot = $(postObjElArr).find(
        '[aria-label="Actions for this post"]'
      );

      $(Findthedot).click();
      
      if (maInterval1) {
        clearInterval(maInterval1);
      }
     
      var popUpmenuBox;
      maInterval1 = setInterval(function () {
        
        // $.each($(".j34wkznp.qp9yad78.pmk7jnqg.kr520xx4"), function () { // commented by ankur
        $.each($(".x1qjc9v5.x3vj7og.x78zum5.xdt5ytf.x1n2onr6.x1al4vs7"), function () {  
          if (!$(this).is(":hidden")) {
            popUpmenuBox = $(this);
          }
        });

        PopupMenuBox_children = $(popUpmenuBox[0]).find('[class="x193iq5w xeuugli x13faqbe x1vvkbs x10flsy6 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x41vudc x1f6kntn xvq8zen xk50ysn xzsf02u x1yc453h"]');
        
        // for window we are fetching the span
        if (PopupMenuBox_children.length == 0) {
          PopupMenuBox_children = $(popUpmenuBox[0]).find('span[dir="auto"]');
        }
        
        if ($(PopupMenuBox_children).length) { 
          clearInterval(maInterval1);
  
          $(".textChanging").html(
            "Initialized " +
            configData.appName +
            ".<br>Running " +
            configData.appName +
            ".<br> " +
            configData.appName +
            " is fetching 'why I am seeing this ad' data<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
          );
          // whyThisAdd(postObjElArr[0], $(PopupMenuBox_children).children()); // commented by ankur
          whyThisAdd(postObjElArr[0], PopupMenuBox_children);
        }
      }, 2000);
    }
  });

};

const whyThisAdd = (postObjElArr, PopupMenuBox_children) => {
  var whyAmISeeThisAdd;
  for (let i = 0; i < PopupMenuBox_children.length; i++) {
    if (PopupMenuBox_children[i].innerText === "Why am I seeing this ad?") {
      whyAmISeeThisAdd = PopupMenuBox_children[i];
    }
  }
  
  if (!PopupMenuBox_children.length) return;
  if (postObjElArr && PopupMenuBox_children && whyAmISeeThisAdd) {
    clearInterval(maInterval);
    clearInterval(maInterval1);
    $(whyAmISeeThisAdd).click();
    // return;
    if (maInterval2) {
      clearInterval(maInterval2);
    }
    var immediatePOst = postObjElArr;
    maInterval2 = setInterval(function () {
      var popupWhy = $('div[role="dialog"]').last(); //$(".l081gc3l.ip4hrkex")
      // console.log("popupWhy====", $(popupWhy[0]).find('div[aria-label="Loading..."]'))
      if ($(popupWhy)[0] && $(popupWhy[0]).find('div[aria-label="Loading..."]').length == 0) {
        clearInterval(maInterval2);
        collectWhyAd(postObjElArr, popupWhy);
      }
    }, 2000);
  }
};

const isEmptyObj = function (obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
};

const openAdLib = () => {
  if ($(".rq0escxv.lpgh02oy.du4w35lb.rek2kq2y") != undefined) {
    // console.log($('._u2f'));
    // console.log("i am in this page. 1::: ", $(".rq0escxv.lpgh02oy.du4w35lb.rek2kq2y")[0]);
    scrollToPos($(".rq0escxv.lpgh02oy.du4w35lb.rek2kq2y")[0]);
    // console.log("i am in this page. 2", $(".ihqw7lf3")[4]);
    if ($(".ihqw7lf3")[4] != undefined) {
      // console.log($('._2ph_')[0]);
      scrollToPos($(".ihqw7lf3")[4]);
      if ($(".ihqw7lf3")[5] != undefined) {
        // console.log($('._2ph_')[0]);
        scrollToPos($(".ihqw7lf3")[5]);
        if ($(".ihqw7lf3")[6] != undefined) {
          // console.log($('._2ph_')[0]);
          scrollToPos($(".ihqw7lf3")[6]);

          if ($(".ihqw7lf3")[7] != undefined) {
            // console.log($('._2ph_')[0]);
            scrollToPos($(".ihqw7lf3")[7]);
          }
        }
      }
    }
  }

  if (
    !$(".rq0escxv.lpgh02oy.du4w35lb.rek2kq2y")[0] &&
    !$(".ihqw7lf3")[4] &&
    !$(".ihqw7lf3")[5] &&
    !$(".ihqw7lf3")[6] &&
    !$(".ihqw7lf3")[7]
  ) {
    // && !$("._4ake") && !$("._fuo")[0]) {
    setTimeout(function () {
      openAdLib();
    }, 2000);
  }
  $(".textChanging").html(
    "Initialized " +
    configData.appName +
    ".<br>" +
    configData.appName +
    " is running<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
  );

  // console.log("lpgh02oy : ", $('.lpgh02oy')[1]);
  if ($(".lpgh02oy")[1]) {
    const pageTranpTopDiv = $($(".lpgh02oy")[1]).find(
      ".sjgh65i0.cbu4d94t.j83agx80"
    );
    // console.log("pageTranpTopDiv : ", pageTranpTopDiv);
    var seeAll, isPTText;
    Array.prototype.forEach.call(pageTranpTopDiv, (el, i) => {
      const pagTransparency = $(
        $($(el).find(".ihqw7lf3")[0]).find(".w0hvl6rk.qjjbsfad")[0]
      ).find(
        ".rq0escxv.l9j0dhe7.du4w35lb.j83agx80.pfnyh3mw.i1fnvgqd.bp9cbjyn.owycx6da.btwxx1t3.jeutjz8y"
      );
      // console.log("pagTransparency : ", pagTransparency);
      if ($(pagTransparency[0]).children().eq(0)[0]) {
        var isPageTransparancy = $(pagTransparency[0])
          .children()
          .eq(0)[0].textContent;
        // console.log(isPageTransparancy);
        if (isPageTransparancy.toLowerCase() == "page transparency") {
          // console.log("true");
          seeAll = $($(pagTransparency[0]).children().eq(1)[0]).find("span")[0];
          isPTText = isPageTransparancy;
          // console.log("seeAll "+i+": ", seeAll);
        }
      }
    });
    $(seeAll).click();
    // $(".settings_overlay").css("display", "none");
    // aria-label="Go to Ad Library"
    var adLibInterval = 0;
    adLibInterval = setInterval(() => {
      var ptModal = $('div[aria-label="' + isPTText + '"]')[0];
      // console.log("ptModal : ", ptModal);
      if (ptModal) {
        clearInterval(adLibInterval);
        // setTimeout  (()=>{
        if (ptModal == undefined) ptModal = ptModal1;
        const gotoLib = $(ptModal).children().eq(2)[0];
        // console.log("gotoLib : ", gotoLib);
        setTimeout(() => {
          const gotoLibBlock = $($(gotoLib).find(".d01ig566"));
          const adButton = $(gotoLibBlock[gotoLibBlock.length - 1])
            .children()
            .eq($(gotoLibBlock[gotoLibBlock.length - 1]).children().length - 1)
            .children()
            .children()[0];
          window.location.href =
            "https://www.facebook.com" + $(adButton).attr("href");
        }, 1000);
      }
    }, 1000);
  } else {
    openAdLib();
  }
};

function scrollToPos(el) {
  $("html,body").animate(
    {
      scrollTop: $(el).offset().top - 25,
    },
    "slow"
  );
}

const openCommentSection = (
  finalData,
  key,
  postObjElArr,
  CommentShare,
  isComment,
  commentEle
) => {
  // console.log("opening comment section");
  // console.log("commentEle", commentEle);
  // console.log("commentEle", commentEle[0]);
  // console.log("isComment", isComment);

  // console.log("postObjElArr", postObjElArr);
  
  if (isComment) {
    $(".textChanging").html(
      "Initialized " +
      configData.appName +
      ".<br>" +
      configData.appName +
      " is running.<br> Fetched 'why i'm seeing this ad' data.   <br>Grabed reaction counts.<br>It is opening comment Section<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
    );

    // console.log("postObjElArr length 8888888888", $(postObjElArr).find(".x1jx94hy.x12nagc").length);
    if ($(postObjElArr).find(".x1jx94hy.x12nagc").length == 0) {
      var isDivFound = 0;
      // console.log("yyyy", commentEle[0]);
      // return;
      // $(CommentShare[0]).find("span")[0].click();
      if (commentEle && commentEle.length > 0) {
        commentEle[0].click();
      }
     
      // console.log("yyyy button clicked");
      // return;
      var maIntervalOCA5 = setInterval(async () => {
        var requiredAllCommentBox = $(postObjElArr).find(".x1jx94hy.x12nagc");

        // if (!requiredAllCommentBox) {
        //   $(commentEle[0]).find('div[role="button"]')[0].click();
        // }
        // console.log("maIntervalOCA5 calling==", requiredAllCommentBox);
        // return;

        // Portion added by ankur to grab the comments when comment is comming in modal
        if (isDivFound >= 5) {
          clearInterval(maIntervalOCA5);
          var maIntervalOCA6 = setInterval(async () => {
            if (isDivFound == 11) {
              setTimeout(() => {
                saveFinalData(finalData, key, $(postObjElArr));
              }, 1000);
            }
            // var cmDiv = $('div[class="xwya9rg x11i5rnm x1e56ztr x1mh8g0r xh8yej3"]').find('div[class="x1jx94hy"]').find('ul');
            var cmDiv = $('div[class="xwya9rg x11i5rnm x1e56ztr x1mh8g0r xh8yej3"]').find('div[class="x1jx94hy"]');

            if (isDivFound >= 9) {
              $.each($(".x1jx94hy"), function () { 
                if (!$(this).is(":hidden")) {
                  requiredAllCommentBox = $(this);
                }
              });
            }

            if (!cmDiv && cmDiv.length == 0) {
              isDivFound++;
              return;
            }
            // console.log("cmDiv==", cmDiv);
            
            
            requiredAllCommentBox = cmDiv
            if (requiredAllCommentBox) {
              clearInterval(maIntervalOCA6);
              checkComment2(finalData, key, postObjElArr, CommentShare, isComment, requiredAllCommentBox);
            }
            isDivFound++;
          }, 1000);
          return;
        } // End if (requiredAllCommentBox) {
        // End of the Portion added by ankur to grab the comments when comment is comming in modal
        
        requiredAllCommentBox = requiredAllCommentBox[requiredAllCommentBox.length - 1];
        
        if (requiredAllCommentBox) {
          clearInterval(maIntervalOCA5);
          checkComment(finalData, key, postObjElArr, CommentShare, isComment);
        } else {
          if ($('div[role="dialog"]').length < 1 && commentEle && commentEle.length > 0) {
            $(commentEle[0]).find('div[role="button"]')[0].click();
          }
        }
        isDivFound = isDivFound + 1;
      }, 1000);
    } else {
      // console.log("zzzz");
      checkComment(finalData, key, postObjElArr, CommentShare, isComment);
    }
  } else {

    setTimeout(() => {
      saveFinalData(finalData, key, $(postObjElArr));
    }, 1000);
  }
};

//=============================For popup Comment Writing Writing this code
const checkComment2 = (
  finalData,
  key,
  postObjElArr,
  CommentShare,
  isComment,
  requiredAllCommentBox
) => {
  // if(isComment){
  $(".textChanging").html(
    "Initialized " +
    configData.appName +
    ".<br>" +
    configData.appName +
    " is running.<br> Fetched 'why i'm seeing this ad' data.   <br>Grabed reaction counts.<br>It has started scanning all comments<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
  );
  const commentSectionOpen = requiredAllCommentBox;
  // console.log("commentSectionOpen>>>>>>>>>>", commentSectionOpen);

  // ======================= Code of Ankur
  var commentSectionBlockOpen = $(commentSectionOpen).find('ul');
  // ====================== End code of Ankur
  // console.log("commentSectionBlockOpen ------> ", commentSectionBlockOpen)
  if (commentSectionBlockOpen.length) {
    
    let allCommentBox = $(commentSectionBlockOpen[0]).children();
    // console.log("allCommentDD >>>>>>>>>>", allCommentBox);

    var olderComment = "0s";
    Array.prototype.forEach.call(allCommentBox, (el, i) => {
      // console.log("each comment : ", el);
      const eachParentComment = $(el).find(
        'div[aria-label^="Comment by "]'
      )[0];
      // console.log("eachParentComment : ", eachParentComment);
      let timeList = $(
        $($(eachParentComment).find("ul")[0]).children().last()
      )
        .children()
        .eq(0)
        .text();

        // console.log("timeList : ", timeList);
      

      if (timeList == "Edited") {
        timeList = $(
          $($(eachParentComment).find("ul")[0]).children().last()
        )
          .prev()
          .children()
          .eq(0)
          .text();
      }
      // console.log('timelist', olderComment, timeList);
      if (timeList != "Page responded privately") {
        if (
          priorityLevel(olderComment[olderComment.length - 1]) <
          priorityLevel(timeList[timeList.length - 1])
        ) {
          olderComment = timeList;
        } else if (
          priorityLevel(olderComment[olderComment.length - 1]) ==
          priorityLevel(timeList[timeList.length - 1])
        ) {
          // console.log("same priority.");
          // console.log('length', olderComment.slice(0, olderComment.length - 1), timeList.slice(0, timeList.length - 1));
          if (
            parseInt(olderComment.slice(0, olderComment.length - 1)) <
            parseInt(timeList.slice(0, timeList.length - 1))
          ) {
            olderComment = timeList;
          }
        }
      }
      // console.log("olderComment : ", olderComment);
      if (allCommentBox.length - 1 == i) {
        finalData.oldestCommentAge = olderComment;
        // console.log("olderComment : ", olderComment);
        setTimeout(() => {
          saveFinalData(finalData, key, $(postObjElArr));
        }, 1000);
      }
    }); // End Array.prototype.forEach.call(allCommentBox, (el, i) => {
  } else {
    // console.log("commentSectionBlockOpen else");
    setTimeout(() => {
      saveFinalData(finalData, key, $(postObjElArr));
    }, 1000);          
  }
  
};

//============================= End popup comment

const checkComment = (
  finalData,
  key,
  postObjElArr,
  CommentShare,
  isComment
) => {
  // if(isComment){
  $(".textChanging").html(
    "Initialized " +
    configData.appName +
    ".<br>" +
    configData.appName +
    " is running.<br> Fetched 'why i'm seeing this ad' data.   <br>Grabed reaction counts.<br>It has started scanning all comments<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
  );
  const commentSectionOpen = $(postObjElArr).find(".x1jx94hy.x12nagc");

  // ======================= Code of Ankur
  var commentSectionBlockOpen = $(commentSectionOpen[0]).children().eq(5);
  // ====================== End code of Ankur

  if (commentSectionBlockOpen.length) {
    
    const allCommentDD = $(commentSectionOpen[0]).find(
      ".alzwoclg.cgu29s5g.h2dzpz9h.om3e55n1"
    );

    // const allCommentDD = $(commentSectionOpen[0]).find(
    //   ".x6s0dn4 .x78zum5 .xdj266r .x11i5rnm .xat24cr .x1mh8g0r .xe0p6wg"
    // );

    
    // console.log("allCommentDD in commentSectionBlock Open : ", allCommentDD[0]);
    const dropDown = $(allCommentDD[0]).find("span");
    // console.log("dropDown : ", dropDown[0]);
    
    // if (dropDown.length) {
    //   $(dropDown[0]).click();
    //   console.log("if (dropDown.length)");
    //   return;
    //   var maIntervalOCA2 = setInterval(async () => {
    //     // console.log("postObjElArr : ", postObjElArr);
    //     var requiredAllCommentBox = $(".j34wkznp.qp9yad78.pmk7jnqg.kr520xx4");
    //     requiredAllCommentBox =
    //       requiredAllCommentBox[requiredAllCommentBox.length - 1];
    //     if (requiredAllCommentBox) {
    //       clearInterval(maIntervalOCA2);
    //       const parentBlocks = $(
    //         $(requiredAllCommentBox).find(
    //           ".j83agx80.cbu4d94t.buofh1pr.l9j0dhe7"
    //         )[0]
    //       )
    //         .children()
    //         .children()
    //         .eq(2);
    //       // console.log('parentBlocks : ', $(parentBlocks[0]).find('.qzhwtbm6.knvmm38d')[0]);
    //       $(parentBlocks[0]).find(".qzhwtbm6.knvmm38d")[0].click();
    //       var maIntervalOCA4 = setInterval(async () => {
    //         const commentSection = $(postObjElArr).find(".cwj9ozl2.tvmbv18p");
    //         var commentSectionBlock = $(commentSection[0]).children().eq(2);
    //         // console.log('commentSectionBlock : ', commentSectionBlock[0]);
    //         if ($(commentSectionBlock).children().length) {
    //           clearInterval(maIntervalOCA4);
    //           viewPreviousComments(postObjElArr, () => {
    //             if (maIntervalOCA) clearInterval(maIntervalOCA);
    //             maIntervalOCA = setInterval(async () => {
    //               $(".textChanging").html(
    //                 "Initialized " +
    //                 configData.appName +
    //                 ".<br>" +
    //                 configData.appName +
    //                 " is running.<br> Fetched 'why i'm seeing this ad' data. <br> Grabed all reaction Counts.<br>scaned all the comments. <br> We are almost there. <br>" +
    //                 configData.appName +
    //                 " is grabing oldest comment age<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
    //               );
    //               const commentSection =
    //                 $(postObjElArr).find(".cwj9ozl2.tvmbv18p");
    //               // console.log("commentSection : ", commentSection);
    //               if ($(commentSection.length).children()) {
    //                 clearInterval(maIntervalOCA);
    //                 // console.log("commentSection : ", commentSection);
    //                 const allCommentBox = $(
    //                   $($(commentSection).find("ul")[1])[0]
    //                 ).children();
    //                 // console.log("commentSection  ul children  : ", allCommentBox);
    //                 var olderComment = "0s";
    //                 Array.prototype.forEach.call(allCommentBox, (el, i) => {
    //                   // console.log("each comment : ", el);
    //                   const eachParentComment = $(el).find(
    //                     'div[aria-label^="Comment by "]'
    //                   )[0];
    //                   // console.log("eachParentComment : ", eachParentComment);
    //                   let timeList = $(
    //                     $($(eachParentComment).find("ul")[0]).children().last()
    //                   )
    //                     .children()
    //                     .eq(0)
    //                     .text();

    //                   // console.log('time 1 : ',$(
    //                   //   $($(eachParentComment).find("ul")[0]).children().last()
    //                   // ).children().eq(0))

    //                   if (timeList == "Edited") {
    //                     timeList = $(
    //                       $($(eachParentComment).find("ul")[0])
    //                         .children()
    //                         .last()
    //                     )
    //                       .prev()
    //                       .children()
    //                       .eq(0)
    //                       .text();
    //                     // console.log($(
    //                     //   $($(eachParentComment).find("ul")[0]).children().last()
    //                     // ).prev().children().eq(1).text());
    //                   }

    //                   // console.log('timelist', olderComment, timeList);
    //                   if (timeList != "Page responded privately") {
    //                     if (
    //                       priorityLevel(olderComment[olderComment.length - 1]) <
    //                       priorityLevel(timeList[timeList.length - 1])
    //                     ) {
    //                       olderComment = timeList;
    //                     } else if (
    //                       priorityLevel(
    //                         olderComment[olderComment.length - 1]
    //                       ) == priorityLevel(timeList[timeList.length - 1])
    //                     ) {
    //                       // console.log("same priority.");
    //                       // console.log('length', olderComment.slice(0, olderComment.length - 1), timeList.slice(0, timeList.length - 1));
    //                       if (
    //                         parseInt(
    //                           olderComment.slice(0, olderComment.length - 1)
    //                         ) < parseInt(timeList.slice(0, timeList.length - 1))
    //                       ) {
    //                         olderComment = timeList;
    //                       }
    //                     }
    //                   }
    //                   // console.log("olderComment : ", olderComment);
    //                   if (allCommentBox.length - 1 == i) {
    //                     finalData.oldestCommentAge = olderComment;
    //                     // console.log("finalData : ", finalData.reasonsOfAds);
    //                     setTimeout(() => {
    //                       saveFinalData(finalData, key, $(postObjElArr));
    //                     }, 1000);
    //                   }
    //                 });
    //               }
    //             }, 1000);
    //           });
    //         }
    //       });
    //     }
    //   }, 300);
    // } else {


      // const commentSection = $(postObjElArr).find(".cwj9ozl2.tvmbv18p"); // commented by ankur
      
      
      const commentSection = $(postObjElArr).find(".x1jx94hy.x12nagc");
      // console.log("commentSection ===", commentSection);
      // console.log("if (dropDown.length) { ELSE");
      // return;
      viewPreviousComments(postObjElArr, () => {
        if (maIntervalOCA) clearInterval(maIntervalOCA);
        maIntervalOCA = setInterval(async () => {
          $(".textChanging").html(
            "Initialized " +
            configData.appName +
            ".<br>" +
            configData.appName +
            " is running.<br> Fetched 'why i'm seeing this ad' data. <br> Grabed all reaction Counts.<br>scaned all the comments. <br> We are almost there. <br>" +
            configData.appName +
            " is grabing oldest comment age<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
          );
          // const commentSection = $(postObjElArr).find(".cwj9ozl2.tvmbv18p"); // Commented by Ankur
          const commentSection = $(postObjElArr).find(".x1jx94hy.x12nagc");
          // console.log("commentSection ffffffffff: ", commentSection);
          
          if ($(commentSection.length).children()) {
            clearInterval(maIntervalOCA);
            // console.log("commentSection : ", commentSection);
            // return;
            const allCommentBox = $(
              $($(commentSection).find("ul")[1])[0]
            ).children();
            // console.log("commentSection  ul children  : ", allCommentBox);
            
            var olderComment = "0s";
            Array.prototype.forEach.call(allCommentBox, (el, i) => {
              // console.log("each comment : ", el);
              const eachParentComment = $(el).find(
                'div[aria-label^="Comment by "]'
              )[0];
              // console.log("eachParentComment : ", eachParentComment);
              let timeList = $(
                $($(eachParentComment).find("ul")[0]).children().last()
              )
                .children()
                .eq(0)
                .text();
              // console.log('time 1 : ',$(
              //   $($(eachParentComment).find("ul")[0]).children().last()
              // ).children().eq(0))

              if (timeList == "Edited") {
                timeList = $(
                  $($(eachParentComment).find("ul")[0]).children().last()
                )
                  .prev()
                  .children()
                  .eq(0)
                  .text();
                // console.log($(
                //   $($(eachParentComment).find("ul")[0]).children().last()
                // ).prev());
                // return false
              }
              // console.log('timelist', olderComment, timeList);
              if (timeList != "Page responded privately") {
                if (
                  priorityLevel(olderComment[olderComment.length - 1]) <
                  priorityLevel(timeList[timeList.length - 1])
                ) {
                  olderComment = timeList;
                } else if (
                  priorityLevel(olderComment[olderComment.length - 1]) ==
                  priorityLevel(timeList[timeList.length - 1])
                ) {
                  // console.log("same priority.");
                  // console.log('length', olderComment.slice(0, olderComment.length - 1), timeList.slice(0, timeList.length - 1));
                  if (
                    parseInt(olderComment.slice(0, olderComment.length - 1)) <
                    parseInt(timeList.slice(0, timeList.length - 1))
                  ) {
                    olderComment = timeList;
                  }
                }
              }
              // console.log("olderComment : ", olderComment);
              if (allCommentBox.length - 1 == i) {
                finalData.oldestCommentAge = olderComment;
                // console.log("finalData : ", finalData.reasonsOfAds);
                setTimeout(() => {
                  saveFinalData(finalData, key, $(postObjElArr));
                }, 1000);
              }
            });
          }
        }, 1000);
      });
      // }
    
    
    // }
  } else {
    // console.log("commentSectionBlockOpen else");
    setTimeout(() => {
      saveFinalData(finalData, key, $(postObjElArr));
    }, 1000);
    return;
    const allComments = $(CommentShare[0]).children().children()[0];
    // console.log("All Comments are there", allComments);
    $(allComments).click();
    var maIntervalOCA1 = setInterval(async () => {
      const commentSection = $(postObjElArr).find(".k0kqjr44.laatuukc");
      var commentSectionBlock = $(commentSection[0]).children().eq(2);
      // console.log('commentSectionBlock : ', commentSectionBlock[0]);
      if ($(commentSectionBlock).children().length) {
        clearInterval(maIntervalOCA1);
        // console.log("commentSection in if : ", commentSection[0]);
        const allCommentDD = $(commentSection[0]).find(
          ".bp9cbjyn.j83agx80.kvgmc6g5.cxmmr5t8.oygrvhab.hcukyx3x.h3fqq6jp"
        );
        // console.log("allCommentDD : ", allCommentDD[0]);
        const dropDown = $(allCommentDD[0]).find("span");
        // console.log("dropDown : ", dropDown[0]);
        $(dropDown[0]).click();
        var maIntervalOCA2 = setInterval(async () => {
          // console.log("postObjElArr : ", postObjElArr);
          var requiredAllCommentBox = $(".j34wkznp.qp9yad78.pmk7jnqg.kr520xx4");
          requiredAllCommentBox =
            requiredAllCommentBox[requiredAllCommentBox.length - 1];
          if (requiredAllCommentBox) {
            clearInterval(maIntervalOCA2);
            const parentBlocks = $(
              $(requiredAllCommentBox).find(
                ".j83agx80.cbu4d94t.buofh1pr.l9j0dhe7"
              )[0]
            )
              .children()
              .children()
              .eq(2);
            // console.log('parentBlocks : ', $(parentBlocks[0]).find('.qzhwtbm6.knvmm38d')[0]);
            $(parentBlocks[0]).find(".qzhwtbm6.knvmm38d")[0].click();
            var maIntervalOCA4 = setInterval(async () => {
              const commentSection = $(postObjElArr).find(".cwj9ozl2.tvmbv18p");
              var commentSectionBlock = $(commentSection[0]).children().eq(2);
              // console.log('commentSectionBlock : ', commentSectionBlock[0]);
              if ($(commentSectionBlock).children().length) {
                clearInterval(maIntervalOCA4);
                viewPreviousComments(postObjElArr, () => {
                  if (maIntervalOCA) clearInterval(maIntervalOCA);
                  maIntervalOCA = setInterval(async () => {
                    $(".textChanging").html(
                      "Initialized " +
                      configData.appName +
                      ".<br>" +
                      configData.appName +
                      " is running.<br> Fetched 'why i'm seeing this ad' data. <br> Grabed all reaction Counts.<br>scaned all the comments. <br> We are almost there. <br>" +
                      configData.appName +
                      " is grabing oldest comment age<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
                    );
                    const commentSection =
                      $(postObjElArr).find(".cwj9ozl2.tvmbv18p");
                    // console.log("commentSection : ", commentSection);
                    if ($(commentSection.length).children()) {
                      clearInterval(maIntervalOCA);
                      // console.log("commentSection : ", commentSection);
                      const allCommentBox = $(
                        $($(commentSection).find("ul")[1])[0]
                      ).children();
                      // console.log("commentSection  ul children  : ", allCommentBox);
                      var olderComment = "0s";
                      Array.prototype.forEach.call(allCommentBox, (el, i) => {
                        // console.log("each comment : ", el);
                        const eachParentComment = $(el).find(
                          'div[aria-label^="Comment by "]'
                        )[0];
                        // console.log("eachParentComment : ", eachParentComment);
                        let timeList = $(
                          $($(eachParentComment).find("ul")[0])
                            .children()
                            .last()
                        )
                          .children()
                          .eq(0)
                          .text();

                        if (timeList == "Edited") {
                          timeList = $(
                            $($(eachParentComment).find("ul")[0])
                              .children()
                              .last()
                          )
                            .prev()
                            .children()
                            .eq(0)
                            .text();
                          // console.log($(
                          //   $($(eachParentComment).find("ul")[0]).children().last()
                          // ).prev());
                          // return false
                        }
                        // console.log('timelist', olderComment, timeList);
                        if (timeList != "Page responded privately") {
                          if (
                            priorityLevel(
                              olderComment[olderComment.length - 1]
                            ) < priorityLevel(timeList[timeList.length - 1])
                          ) {
                            olderComment = timeList;
                          } else if (
                            priorityLevel(
                              olderComment[olderComment.length - 1]
                            ) == priorityLevel(timeList[timeList.length - 1])
                          ) {
                            // console.log("same priority.");
                            // console.log('length', olderComment.slice(0, olderComment.length - 1), timeList.slice(0, timeList.length - 1));
                            if (
                              parseInt(
                                olderComment.slice(0, olderComment.length - 1)
                              ) <
                              parseInt(timeList.slice(0, timeList.length - 1))
                            ) {
                              olderComment = timeList;
                            }
                          }
                        }
                        // console.log("olderComment : ", olderComment);
                        if (allCommentBox.length - 1 == i) {
                          finalData.oldestCommentAge = olderComment;
                          // console.log("finalData : ", finalData.reasonsOfAds);
                          setTimeout(() => {
                            saveFinalData(finalData, key, $(postObjElArr));
                          }, 1000);
                        }
                      });
                    }
                  }, 1000);
                });
              }
            });
          }
        }, 300);
      }
    }, 2000);
  }
  // } else{
  //   // console.log("finalData : ", finalData.reasonsOfAds);
  //   setTimeout(()=>{saveFinalData(finalData, key, $(postObjElArr));},1000);
  // }
};

const reactionGrab = (
  finalData,
  key,
  postObjElArr,
  CommentShare,
  isComment,
  commentEle
) => {
  
  $(".textChanging").html(
    "Initialized " +
    configData.appName +
    ".<br>" +
    configData.appName +
    " is running.<br> Fetched 'why i'm seeing this ad' data.<br>It is grabing reaction counts<div class='loadDots_settingsMA'><span style=' top: -5px; position: relative; '></span><span></span><span></span></div> <br>Please don't close or refresh the page"
  );
  const reactArr = postObjElArr.querySelectorAll(
    "span[aria-label='See who reacted to this'] div"
  )[0]; // role="button"
  
  if (reactArr) {
    reactArr.click();
    var reactInrvl = setInterval(() => {
      const reactDiv = $('div[role="dialog"].x1n2onr6.x1ja2u2z.x1afcbsf.xdt5ytf.x1a2a7pz.x71s49j.x1qjc9v5.x1qpq9i9.xdney7k.xu5ydu1.xt3gfkd.x78zum5.x1plvlek.xryxfnj.xcatxm7.x1n7qst7.xh8yej3')[0];
      
      if (reactDiv && !($(reactDiv).attr("aria-label") === "Loading...")) {

        clearInterval(reactInrvl);
        var reactionsInterval = setInterval(() => {
          let reactionsArr = reactDiv.querySelectorAll(
            "div[aria-hidden='false']"
          );
          
          if (reactionsArr.length) {
            clearInterval(reactionsInterval);
            var reactEmot = [];
            var reactCount = [];

            // console.log("reactionsArr====", reactionsArr[1]);
            // console.log("toLowerCase====", reactionsArr[1].innerText.toLowerCase());
            // return;
            
            if (reactionsArr[1].innerText.toLowerCase() == "more") {
              
              for (var i = 3; i < reactionsArr.length; i++) {
                const reactImg = reactionsArr[i]
                  .querySelector("img")
                  .getAttribute("src");
                  
                const reactText = reactionsArr[i].innerText;
                reactEmot.push(reactImg);
                reactCount.push(reactText);
              }
              
              $($(reactionsArr[1]).find('span'))[0].click();
            
              var moreIntrvl = setInterval(() => {
                // console.log($('div[role="menuitemradio"]'));
                const moreItems = $('div[role="menuitemradio"]');
                if (moreItems.length) {
                  clearInterval(moreIntrvl);
                  // moreItems.forEach((el) => {
                  for (var i = 0; i < moreItems.length; ++i) {
                    // console.log("more el : ", moreItems[i]);
                    const moreReactImg = moreItems[i]
                      .querySelector("img")
                      .getAttribute("src");
                    const morerReactText = moreItems[i].innerText;
                   
                    reactEmot.push(moreReactImg);
                    reactCount.push(morerReactText);
                  }
                  
                  finalData.reactEmot = reactEmot;
                  finalData.reactCount = reactCount;
                  
                  $(reactDiv).find('div[aria-label="Close"]')[0].click();
                  
                  setTimeout(() => {
                    // console.log("isComment 1: ", isComment);
                    openCommentSection(
                      finalData,
                      key,
                      postObjElArr,
                      CommentShare,
                      isComment,
                      commentEle
                    );
                    // checkComment(finalData, key, postObjElArr, CommentShare, isComment)
                  }, 1500);
                }
              }, 500);
            } else if (reactionsArr[1].innerText.toLowerCase() == "all") {
              // console.log("all-----------------")
              for (var i = 2; i < reactionsArr.length; i++) {
                const reactImg = reactionsArr[i]
                  .querySelector("img")
                  .getAttribute("src");
                const reactText = reactionsArr[i].innerText;
                reactEmot.push(reactImg);
                reactCount.push(reactText);
              }
              // console.log("reactEmot 2113", reactEmot);
              // console.log("reactText 2114", reactText);
              // return;
              
              finalData.reactEmot = reactEmot;
              finalData.reactCount = reactCount;
              $(reactDiv).find('div[aria-label="Close"]')[0].click();
              setTimeout(() => {
                
                openCommentSection(
                  finalData,
                  key,
                  postObjElArr,
                  CommentShare,
                  isComment,
                  commentEle
                );
                // checkComment(finalData, key, postObjElArr, CommentShare, isComment)
              }, 1000);
            } else {
              
              const reactText = reactionsArr[1].innerText;
              var imagesTags = $($(reactionsArr[1]).find('div[role="tablist"]')[0]).find('img');
             
              if (imagesTags.length > 0) {
                for (var i = 0; i < imagesTags.length; i++) {
                  if (!reactEmot.includes(imagesTags[i].getAttribute("src"))) {
                    reactEmot.push(imagesTags[i].getAttribute("src"));
                    reactCount.push(reactText.split("\n")[i+2]);
                  }
                } // End for (var i = 0; i < imagesTags.length; i++) {
              } else {
                reactCount.push(reactText.split("\n")[2]);
              }
              // const reactImg = reactionsArr[1]
              //   .querySelector("img")
              //   .getAttribute("src");
              
              // console.log("reactImg--none", reactImg)
             
              // reactEmot.push(reactImg);
              // reactCount.push(reactText);
              // console.log("reactEmot--none", reactEmot)
              // console.log("reactCount--none", reactCount)
              finalData.reactEmot = reactEmot;
              finalData.reactCount = reactCount;
              $(reactDiv).find('div[aria-label="Close"]')[0].click();
              setTimeout(() => {
                openCommentSection(
                  finalData,
                  key,
                  postObjElArr,
                  CommentShare,
                  isComment,
                  commentEle
                );
                // console.log("isComment : ", isComment);
                // checkComment(finalData, key, postObjElArr, CommentShare, isComment)
              }, 1000);
            }
          }
        }, 300);
      }
    }, 500);
  } else {
    openCommentSection(finalData, key, postObjElArr, CommentShare, isComment, commentEle);

    // checkComment(finalData, key, postObjElArr, CommentShare, isComment)
    // console.log("isComment : ", isComment);
  }
};
