var $ = (jQuery = require("jquery"));
var user = require("./helper.js");

// console.log('I am in login page');
chrome.storage.local.get(['user'], function(res){
    // console.log('user : ',res.user);
    if(res.user !== undefined && res.user !== null) {
    // console.log('token : ',res.user.token);
    if(res.user.token !==null && res.user.token !== undefined){
      window.location.href = "./popup.html";
    }else{
      // window.location.href = "./login.html";
    }
  }
})



   $(document).ready(function(){
     // console.log("document is ready.")
    $("#eye").click(function (e) {
    e.preventDefault();
    if(password.type === 'password'){
       password.type ="text";
       $('#eyehide').hide();
       $('.passwordHide').show();
     }
      else{
      password.type ="password";
      $('.passwordHide').hide();
       $('#eyehide').show();
    }
  })

  $("#forgotPassBtn").click(function(){
    window.location.href = "./forgot.html"
  })

  // $("#signUp").click(function(){
  //   window.location.href = "./signup.html"
  // })


  $("#login").click(function () {
    // console.log("Login button clicked.")
    var email = $("#email").val();
    // console.log("email :: ", email)
    var password = $("#password").val();
    // console.log("password :: ", password)

 
   if (!validateFields(email, password)) return;
   
   $.getJSON("kyubiSettings.json", function (result) {
    //  chrome.storage.sync.get(["subscription"], (storageData) => {
    //    let subscriptionObject = storageData.subscription;

       getDeviceId(
         email,
         password,
         result.extId,
         result.loginURL
        //  subscriptionObject
       );
    //  });
   });
})

});
  
const validateFields = (email, password = null) => {
  const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  let flag = true;
  if (!email.length) {
    showErrorMsg(".errormsg", "Email should not be left blank", 2000);
    flag = false;
    return flag;
  } else if (!emailRegex.test(email)) {
    showErrorMsg(".errormsg", "Please provide a valid email address", 2000);
    flag = false;
    return flag;
  }
  if (password !== null) {
    if (!password.length) {
      flag = false;
      showErrorMsg(".errormsg", "Password should not be left blank", 2000);
      return flag;
    }
  }
  return flag;
};

const doLoginAuthTwo = (
  email,
  password,
  extensionId,
  loginURL,
  deviceID,
  confirmLogout
  // subscriptionObject
) => {
  $("#overlay").css("display", "block");

  fetch(loginURL, {
    method: "POST", // *GET, POST, PUT, DELETE, etc.
    mode: "cors", // no-cors, cors, *same-origin
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
    },
    body: JSON.stringify({
      email: email,
      password: password,
      extensionId: extensionId,
      deviceId: deviceID,
      confirmLogout: confirmLogout
      // subscription: subscriptionObject,
    }), // body data type must match "Content-Type" headerbody data type must match "Content-Type" header
  })
    .then((response) => response.json())
    .then((res) => {
      const resp = res.data ? res.data : res;
      // console.log("resp ::: ",resp);
      if (resp.token && resp.status == true) {
        saveAccessToken(resp, email, deviceID);
      } else if (!resp.token && resp.status == true) {
        let ConfirmMsg = confirm(resp.message);

        if (ConfirmMsg == true) {
          doLoginAuthTwo(
            email,
            password,
            extensionId,
            loginURL,
            deviceID,
            true
            // subscriptionObject
          );
        } else {
          showErrorMsg(
            ".errormsg",
            resp.message ? resp.message : "Failed to login. Please try again.",
            2000
          );
        }
      } else {
        showErrorMsg(
          ".errormsg",
          resp.message ? resp.message : "Failed to login. Please try again.",
          2000
        );
      }
    })
    .catch((err) => {
      showErrorMsg(".errormsg", "Failed to login. Please contact support", 2000);
    })
    .finally(() => {
      $("#overlay").css("display", "none");
    });
  //});
};

const saveAccessToken = (data, email, uid) => {
  // console.log("data : ",data);
  // console.log("email : ",email);
  // console.log("uid : ",uid);
  const userData = {
    token : data.token,
    plan : data.plan,
    email : email,
    uid : uid
  };
    if (email) {
      chrome.storage.local.set({ emailID: email }, function () {});
    }
  chrome.storage.local.set({user : userData},function(){
    window.location.href = "./popup.html";
  })

};

const showErrorMsg = (el, msg, autohide = false) => {
  $(el).css("display", "block").text(msg);
  if (autohide) {
    setTimeout(function () {
      $(el).slideUp();
    }, autohide);
  }
};

const getDeviceId = function (
  email,
  password,
  extensionId,
  loginURL
  // subscriptionObject
) {
  var navigator_info = window.navigator;
  var screen_info = window.screen;
  var uid = navigator_info.mimeTypes.length;
  uid += navigator_info.userAgent.replace(/\D+/g, "");
  uid += navigator_info.plugins.length;
  uid += screen_info.height || "";
  uid += screen_info.width || "";
  uid += screen_info.pixelDepth || "";
  doLoginAuthTwo(
    email,
    password,
    extensionId,
    loginURL,
    uid,
    false
    // subscriptionObject
  );
};
